import { useState, useEffect, useRef, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { TimerMode, TimerSettings, AmbientSound, FocusStats, TodoItem } from './types';
import { soundEngine } from './utils/audio';
import { AmbientBackground } from './components/AmbientBackground';
import { GlassHeader } from './components/GlassHeader';
import { ModeSelector } from './components/ModeSelector';
import { TimerRing } from './components/TimerRing';
import { GlassControls } from './components/GlassControls';
import { FocusTaskInput } from './components/FocusTaskInput';
import { TodoDrawer } from './components/TodoDrawer';
import { SideTasksWing } from './components/SideTasksWing';
import { SettingsModal } from './components/SettingsModal';
import { ShortcutsModal } from './components/ShortcutsModal';
import { BreathingModal } from './components/BreathingModal';
import { MusicDock } from './components/MusicDock';

const DEFAULT_SETTINGS: TimerSettings = {
  focusDuration: 25,
  shortBreakDuration: 5,
  autoStartBreaks: false,
  autoStartPomodoros: false,
  soundEnabled: true,
  volume: 0.5,
  theme: 'obsidian',
  wallpaperId: 'misty-pines',
  customWallpaperUrl: '',
  wallpaperBlur: 3,
  wallpaperBrightness: 45,
};

export default function App() {
  // Load settings from localStorage
  const [settings, setSettings] = useState<TimerSettings>(() => {
    try {
      const saved = localStorage.getItem('glass_pomo_settings');
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch {
      // fallback
    }
    return DEFAULT_SETTINGS;
  });

  // Current mode: 'focus' | 'shortBreak' | 'stopwatch'
  const [mode, setMode] = useState<TimerMode>('focus');

  // Time remaining in current session (or elapsed for stopwatch, in seconds)
  const [timeLeft, setTimeLeft] = useState<number>(() => settings.focusDuration * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  // Session counts
  const [sessionCount, setSessionCount] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('glass_pomo_session_count') || '0', 10);
    } catch {
      return 0;
    }
  });

  // Daily stats
  const [stats, setStats] = useState<FocusStats>(() => {
    const today = new Date().toISOString().slice(0, 10);
    try {
      const saved = localStorage.getItem('glass_pomo_stats');
      if (saved) {
        const parsed: FocusStats = JSON.parse(saved);
        if (parsed.lastActiveDate === today) return parsed;
      }
    } catch {
      // fallback
    }
    return {
      completedSessions: 0,
      totalFocusMinutes: 0,
      streak: 1,
      lastActiveDate: today,
    };
  });

  // To-Do list state - clean empty state for new users
  const [todos, setTodos] = useState<TodoItem[]>(() => {
    try {
      const saved = localStorage.getItem('glass_pomo_todos');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return [];
  });

  const [activeTodoId, setActiveTodoId] = useState<string | null>(() => {
    return localStorage.getItem('glass_pomo_active_todo_id') || null;
  });

  // Ambient sound
  const [ambientSound, setAmbientSound] = useState<AmbientSound>('none');
  const [volume, setVolume] = useState<number>(settings.volume);

  // Modals & Panels state
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);
  const [isTodosOpen, setIsTodosOpen] = useState(false);
  const [isBreathingOpen, setIsBreathingOpen] = useState(false);
  const [isMusicOpen, setIsMusicOpen] = useState(false);
  const [isZenMode, setIsZenMode] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Timer interval ref
  const timerRef = useRef<number | null>(null);

  // Total duration in seconds for current mode (for stopwatch, defaults to 0)
  const getTotalDuration = useCallback((m: TimerMode, s: TimerSettings) => {
    switch (m) {
      case 'shortBreak':
        return s.shortBreakDuration * 60;
      case 'stopwatch':
        return 0; // counts up starting from 0
      case 'focus':
      default:
        return s.focusDuration * 60;
    }
  }, []);

  const totalDuration = getTotalDuration(mode, settings);

  // Sync todos to localStorage
  const updateTodos = (newTodos: TodoItem[]) => {
    setTodos(newTodos);
    localStorage.setItem('glass_pomo_todos', JSON.stringify(newTodos));
  };

  const handleAddTodo = (text: string, estimatedPomos: number) => {
    const newTodo: TodoItem = {
      id: 'todo_' + Date.now(),
      text,
      completed: false,
      pomodorosEstimated: estimatedPomos,
      pomodorosSpent: 0,
      timeSpentSeconds: 0,
      createdAt: Date.now(),
    };
    const updated = [newTodo, ...todos];
    updateTodos(updated);
    if (!activeTodoId) {
      setActiveTodoId(newTodo.id);
      localStorage.setItem('glass_pomo_active_todo_id', newTodo.id);
      localStorage.setItem('glass_pomo_task', newTodo.text);
    }
  };

  const handleToggleTodo = (id: string) => {
    const updated = todos.map((t) => {
      if (t.id === id) {
        const nextCompleted = !t.completed;
        return {
          ...t,
          completed: nextCompleted,
          completedAt: nextCompleted ? Date.now() : undefined,
        };
      }
      return t;
    });
    updateTodos(updated);
  };

  const handleDeleteTodo = (id: string) => {
    const updated = todos.filter((t) => t.id !== id);
    updateTodos(updated);
    if (activeTodoId === id) {
      setActiveTodoId(null);
      localStorage.removeItem('glass_pomo_active_todo_id');
      localStorage.removeItem('glass_pomo_task');
    }
  };

  const handleSelectActiveTodo = (id: string | null) => {
    setActiveTodoId(id);
    if (id) {
      localStorage.setItem('glass_pomo_active_todo_id', id);
      const target = todos.find((t) => t.id === id);
      if (target) localStorage.setItem('glass_pomo_task', target.text);
    } else {
      localStorage.removeItem('glass_pomo_active_todo_id');
      localStorage.removeItem('glass_pomo_task');
    }
  };

  const handleClearCompleted = () => {
    const updated = todos.filter((t) => !t.completed);
    updateTodos(updated);
    if (activeTodoId) {
      const activeStillExists = updated.some((t) => t.id === activeTodoId);
      if (!activeStillExists) {
        setActiveTodoId(null);
        localStorage.removeItem('glass_pomo_active_todo_id');
        localStorage.removeItem('glass_pomo_task');
      }
    }
  };

  const handleSetCustomTask = (text: string) => {
    if (!text.trim()) {
      setActiveTodoId(null);
      localStorage.removeItem('glass_pomo_active_todo_id');
      localStorage.removeItem('glass_pomo_task');
      return;
    }
    const existing = todos.find((t) => t.text.toLowerCase() === text.trim().toLowerCase());
    if (existing) {
      setActiveTodoId(existing.id);
      localStorage.setItem('glass_pomo_active_todo_id', existing.id);
      localStorage.setItem('glass_pomo_task', existing.text);
    } else {
      handleAddTodo(text.trim(), 1);
    }
  };

  // Adjust remaining time (+/- seconds)
  const handleAdjustTime = (deltaSeconds: number) => {
    if (mode === 'stopwatch') {
      setTimeLeft((prev) => Math.max(0, prev + deltaSeconds));
    } else {
      setTimeLeft((prev) => Math.max(60, prev + deltaSeconds));
    }
  };

  // Settings update
  const handleUpdateSettings = (newSettings: Partial<TimerSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      localStorage.setItem('glass_pomo_settings', JSON.stringify(updated));

      // Reset timer if duration setting changed and timer is paused
      if (!isRunning && mode === 'focus' && newSettings.focusDuration !== undefined) {
        setTimeLeft(newSettings.focusDuration * 60);
      } else if (!isRunning && mode === 'shortBreak' && newSettings.shortBreakDuration !== undefined) {
        setTimeLeft(newSettings.shortBreakDuration * 60);
      }

      if (newSettings.volume !== undefined) {
        setVolume(newSettings.volume);
        soundEngine.setVolume(newSettings.volume);
      }

      return updated;
    });
  };

  // Mode Selection
  const handleSelectMode = (newMode: TimerMode) => {
    if (mode === newMode) return;
    setIsRunning(false);
    if (timerRef.current) clearInterval(timerRef.current);
    setMode(newMode);

    if (newMode === 'focus') {
      setTimeLeft(settings.focusDuration * 60);
    } else if (newMode === 'shortBreak') {
      setTimeLeft(settings.shortBreakDuration * 60);
    } else if (newMode === 'stopwatch') {
      setTimeLeft(0);
    }
  };

  // Play / Pause Toggle
  const handleTogglePlay = () => {
    setIsRunning((prev) => !prev);
  };

  // Reset current session
  const handleReset = () => {
    setIsRunning(false);
    if (timerRef.current) clearInterval(timerRef.current);

    if (mode === 'focus') {
      setTimeLeft(settings.focusDuration * 60);
    } else if (mode === 'shortBreak') {
      setTimeLeft(settings.shortBreakDuration * 60);
    } else if (mode === 'stopwatch') {
      setTimeLeft(0);
    }
  };

  // Skip / Next Mode Transition
  const handleNextMode = useCallback(() => {
    setIsRunning(false);
    if (timerRef.current) clearInterval(timerRef.current);

    if (mode === 'focus') {
      setMode('shortBreak');
      setTimeLeft(settings.shortBreakDuration * 60);
      if (settings.autoStartBreaks) {
        setTimeout(() => setIsRunning(true), 300);
      }
    } else {
      setMode('focus');
      setTimeLeft(settings.focusDuration * 60);
      if (settings.autoStartPomodoros) {
        setTimeout(() => setIsRunning(true), 300);
      }
    }
  }, [mode, settings]);

  // Session Completion Handler
  const handleSessionComplete = useCallback(() => {
    setIsRunning(false);
    if (timerRef.current) clearInterval(timerRef.current);

    if (settings.soundEnabled) {
      soundEngine.playChime();
    }

    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#ffffff', '#cbd5e1', '#94a3b8', '#e2e8f0'],
        disableForReducedMotion: true,
      });
    } catch {
      // Ignore if confetti not supported
    }

    if (mode === 'focus') {
      setSessionCount((prev) => {
        const next = prev + 1;
        localStorage.setItem('glass_pomo_session_count', next.toString());
        return next;
      });

      // Update active task spent count
      if (activeTodoId) {
        setTodos((prev) =>
          prev.map((t) =>
            t.id === activeTodoId
              ? {
                  ...t,
                  pomodorosSpent: (t.pomodorosSpent || 0) + 1,
                  timeSpentSeconds: (t.timeSpentSeconds || 0) + settings.focusDuration * 60,
                }
              : t
          )
        );
      }

      // Update Stats
      const today = new Date().toISOString().slice(0, 10);
      setStats((prev) => {
        const isConsecutive =
          new Date(today).getTime() - new Date(prev.lastActiveDate).getTime() <= 86400000 * 2;
        const newStreak = isConsecutive ? prev.streak + (prev.lastActiveDate === today ? 0 : 1) : 1;

        const updated: FocusStats = {
          completedSessions: prev.completedSessions + 1,
          totalFocusMinutes: prev.totalFocusMinutes + settings.focusDuration,
          streak: newStreak,
          lastActiveDate: today,
        };
        localStorage.setItem('glass_pomo_stats', JSON.stringify(updated));
        return updated;
      });

      // Switch to break
      setMode('shortBreak');
      setTimeLeft(settings.shortBreakDuration * 60);
      if (settings.autoStartBreaks) {
        setTimeout(() => setIsRunning(true), 400);
      }
    } else if (mode === 'shortBreak') {
      setMode('focus');
      setTimeLeft(settings.focusDuration * 60);
      if (settings.autoStartPomodoros) {
        setTimeout(() => setIsRunning(true), 400);
      }
    }
  }, [mode, settings, activeTodoId]);

  // Main Timer Interval Loop
  useEffect(() => {
    if (!isRunning) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = window.setInterval(() => {
      setTimeLeft((prev) => {
        if (mode === 'stopwatch') {
          // Increment stopwatch
          const next = prev + 1;
          // Also accumulate time on active task
          if (activeTodoId && next % 5 === 0) {
            setTodos((all) => {
              const updated = all.map((t) =>
                t.id === activeTodoId ? { ...t, timeSpentSeconds: (t.timeSpentSeconds || 0) + 5 } : t
              );
              localStorage.setItem('glass_pomo_todos', JSON.stringify(updated));
              return updated;
            });
          }
          return next;
        }

        // For countdown modes (focus / break)
        if (prev <= 1) {
          handleSessionComplete();
          return 0;
        }

        // Increment time spent on active task every second
        if (mode === 'focus' && activeTodoId) {
          setTodos((all) => {
            const updated = all.map((t) =>
              t.id === activeTodoId ? { ...t, timeSpentSeconds: (t.timeSpentSeconds || 0) + 1 } : t
            );
            localStorage.setItem('glass_pomo_todos', JSON.stringify(updated));
            return updated;
          });
        }

        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, mode, handleSessionComplete, activeTodoId]);

  // Sound Engine ambient trigger
  const handleSelectSound = (sound: AmbientSound) => {
    setAmbientSound(sound);
    soundEngine.setAmbient(sound);
  };

  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    soundEngine.setVolume(newVol);
    handleUpdateSettings({ volume: newVol });
  };

  // Fullscreen Handler
  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
        setIsFullscreen(false);
      }
    }
  };

  // Format time strings for display
  const mins = Math.floor(timeLeft / 60);
  const secs = timeLeft % 60;
  const formattedTime = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  const modeLabel = mode === 'focus' ? 'Focus' : mode === 'shortBreak' ? 'Break' : 'Stopwatch';

  const activeTodo = todos.find((t) => t.id === activeTodoId);
  const activeTaskText = activeTodo ? activeTodo.text : undefined;
  const activeTaskTimeSpent = activeTodo ? activeTodo.timeSpentSeconds || 0 : undefined;
  const pendingTodosCount = todos.filter((t) => !t.completed).length;

  // Dynamic Browser Tab Title
  useEffect(() => {
    document.title = `${formattedTime} · ${modeLabel} | Lost Walker`;
  }, [formattedTime, modeLabel]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        handleTogglePlay();
      } else if (e.key === 'z' || e.key === 'Z') {
        e.preventDefault();
        setIsZenMode((prev) => !prev);
      } else if (e.key === 'b' || e.key === 'B') {
        e.preventDefault();
        setIsBreathingOpen((prev) => !prev);
      } else if (e.key === 'l' || e.key === 'L') {
        e.preventDefault();
        setIsMusicOpen((prev) => !prev);
      } else if (e.key === 'r' || e.key === 'R') {
        e.preventDefault();
        handleReset();
      } else if (e.key === 's' || e.key === 'S') {
        if (mode !== 'stopwatch') {
          e.preventDefault();
          handleNextMode();
        }
      } else if (e.key === 't' || e.key === 'T') {
        e.preventDefault();
        setIsTodosOpen((prev) => !prev);
      } else if (e.key === 'f' || e.key === 'F') {
        e.preventDefault();
        handleToggleFullscreen();
      } else if (e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        handleSelectSound(ambientSound === 'none' ? 'rain' : 'none');
      } else if (e.key === '?') {
        e.preventDefault();
        setIsShortcutsOpen((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [ambientSound, handleNextMode, mode, timeLeft, isRunning, totalDuration, activeTodoId, todos]);

  return (
    <div className="relative h-screen h-[100dvh] max-h-[100dvh] flex flex-col justify-between text-white selection:bg-white/20 select-none overflow-hidden">
      {/* Liquid Ambient Frosted Glass Background with 4K Wallpaper & Custom Support */}
      <AmbientBackground
        theme={settings.theme}
        mode={mode}
        isRunning={isRunning}
        wallpaperId={settings.wallpaperId}
        customWallpaperUrl={settings.customWallpaperUrl}
        wallpaperBlur={settings.wallpaperBlur}
        wallpaperBrightness={settings.wallpaperBrightness}
      />

      {/* Zen Mode Exit Floating Indicator */}
      {isZenMode && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 animate-pulse">
          <button
            onClick={() => setIsZenMode(false)}
            className="px-3 py-1 rounded-full bg-black/60 hover:bg-black/80 border border-white/20 text-xs text-white/80 hover:text-white transition-all shadow-lg flex items-center gap-1.5 backdrop-blur-md"
          >
            <span>Zen Active · Press 'Z' to exit</span>
          </button>
        </div>
      )}

      {/* Top Glass Navigation Bar (hidden in Zen Mode) */}
      <div
        className={`transition-opacity duration-300 ${
          isZenMode ? 'opacity-0 pointer-events-none' : 'opacity-100'
        }`}
      >
        <GlassHeader
          currentSound={ambientSound}
          onSelectSound={handleSelectSound}
          volume={volume}
          onVolumeChange={handleVolumeChange}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenShortcuts={() => setIsShortcutsOpen(true)}
          onOpenTodos={() => setIsTodosOpen(true)}
          onOpenBreathing={() => setIsBreathingOpen(true)}
          onToggleMusic={() => setIsMusicOpen((prev) => !prev)}
          isMusicOpen={isMusicOpen}
          onToggleZen={() => setIsZenMode((prev) => !prev)}
          todoCount={pendingTodosCount}
          isFullscreen={isFullscreen}
          onToggleFullscreen={handleToggleFullscreen}
          completedToday={stats.completedSessions}
        />
      </div>

      {/* Center Stage with Flanking Left & Right Task Panels */}
      <main className="w-full max-w-6xl mx-auto px-4 sm:px-6 flex items-center justify-center flex-1 min-h-0 overflow-hidden relative">
        {/* Left Side: Active / In-Progress Tasks (Desktop View) - Hidden in Zen */}
        <div
          className={`hidden lg:flex items-center justify-end flex-1 pr-6 xl:pr-10 shrink-0 transition-all duration-300 ${
            isZenMode ? 'opacity-0 pointer-events-none translate-x-4' : 'opacity-100 translate-x-0'
          }`}
        >
          <SideTasksWing
            side="left"
            title="Focus Tasks"
            todos={todos.filter((t) => !t.completed)}
            activeTodoId={activeTodoId}
            onSelectActiveTodo={handleSelectActiveTodo}
            onToggleTodo={handleToggleTodo}
            onDeleteTodo={handleDeleteTodo}
            onAddTodo={handleAddTodo}
            onOpenFullList={() => setIsTodosOpen(true)}
          />
        </div>

        {/* Center Stage: Mode Tabs + Timer Ring + Controls + Focus Intention */}
        <div className="w-full max-w-sm sm:max-w-md flex flex-col items-center justify-center shrink-0">
          {/* Mode Selector Tabs (Pomodoro | Break | Stopwatch) - Dim in Zen */}
          <div
            className={`mb-2 sm:mb-3 shrink-0 transition-opacity duration-300 ${
              isZenMode ? 'opacity-20 hover:opacity-100' : 'opacity-100'
            }`}
          >
            <ModeSelector
              currentMode={mode}
              onSelectMode={handleSelectMode}
              isRunning={isRunning}
            />
          </div>

          {/* Circular Glass Timer / Stopwatch Display */}
          <TimerRing
            timeLeft={timeLeft}
            totalDuration={totalDuration}
            isRunning={isRunning}
            mode={mode}
            theme={settings.theme}
            onAdjustTime={handleAdjustTime}
          />

          {/* Glass Controls (Play/Pause, Reset, Skip) */}
          <div
            className={`mt-2 sm:mt-3 mb-2 sm:mb-3 w-full flex justify-center shrink-0 transition-opacity duration-300 ${
              isZenMode ? 'opacity-40 hover:opacity-100' : 'opacity-100'
            }`}
          >
            <GlassControls
              isRunning={isRunning}
              isStopwatch={mode === 'stopwatch'}
              onTogglePlay={handleTogglePlay}
              onReset={handleReset}
              onSkip={handleNextMode}
              sessionCount={sessionCount}
            />
          </div>

          {/* Minimal Focus Task Intention Bar */}
          <div className="w-full flex justify-center shrink-0">
            <FocusTaskInput
              activeTaskText={activeTaskText}
              activeTaskTimeSpent={activeTaskTimeSpent}
              onOpenTodoList={() => setIsTodosOpen(true)}
              onCompleteActiveTask={() => {
                if (activeTodoId) handleToggleTodo(activeTodoId);
              }}
              onClearActiveTask={() => {
                handleSelectActiveTodo(null);
              }}
              onSetCustomTask={handleSetCustomTask}
            />
          </div>
        </div>

        {/* Right Side: Done / Completed Tasks (Desktop View) - Hidden in Zen */}
        <div
          className={`hidden lg:flex items-center justify-start flex-1 pl-6 xl:pl-10 shrink-0 transition-all duration-300 ${
            isZenMode ? 'opacity-0 pointer-events-none -translate-x-4' : 'opacity-100 translate-x-0'
          }`}
        >
          <SideTasksWing
            side="right"
            title="Completed"
            todos={todos.filter((t) => t.completed)}
            activeTodoId={activeTodoId}
            onSelectActiveTodo={handleSelectActiveTodo}
            onToggleTodo={handleToggleTodo}
            onDeleteTodo={handleDeleteTodo}
            onOpenFullList={() => setIsTodosOpen(true)}
          />
        </div>
      </main>

      {/* Ultra-Quiet Clean Footer (No clutter, single row) */}
      <footer
        className={`w-full py-2 text-center z-10 shrink-0 transition-opacity duration-300 ${
          isZenMode ? 'opacity-0' : 'opacity-100'
        }`}
      >
        <span className="text-[10px] font-mono-numbers text-white/25 tracking-widest uppercase">
          Focus · Breathe · Flow
        </span>
      </footer>

      {/* Lo-Fi Music Widget Dock */}
      <MusicDock
        isOpen={isMusicOpen}
        onToggle={() => setIsMusicOpen(false)}
      />

      {/* Guided Breathwork Modal */}
      <BreathingModal
        isOpen={isBreathingOpen}
        onClose={() => setIsBreathingOpen(false)}
      />

      {/* To-Do Slide-Over Glass Drawer */}
      <TodoDrawer
        isOpen={isTodosOpen}
        onClose={() => setIsTodosOpen(false)}
        todos={todos}
        activeTodoId={activeTodoId}
        onSelectActiveTodo={handleSelectActiveTodo}
        onAddTodo={handleAddTodo}
        onToggleTodo={handleToggleTodo}
        onDeleteTodo={handleDeleteTodo}
        onClearCompleted={handleClearCompleted}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
      />

      {/* Shortcuts Sheet */}
      <ShortcutsModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
      />
    </div>
  );
}
