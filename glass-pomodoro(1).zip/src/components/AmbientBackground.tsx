import React from 'react';
import { GlassTheme, TimerMode } from '../types';
import { BUILTIN_WALLPAPERS } from '../utils/wallpapers';

interface AmbientBackgroundProps {
  theme: GlassTheme;
  mode: TimerMode;
  isRunning: boolean;
  wallpaperId?: string;
  customWallpaperUrl?: string;
  wallpaperBlur?: number;
  wallpaperBrightness?: number;
}

export const AmbientBackground: React.FC<AmbientBackgroundProps> = ({
  theme,
  mode,
  isRunning,
  wallpaperId = 'none',
  customWallpaperUrl,
  wallpaperBlur = 4,
  wallpaperBrightness = 50,
}) => {
  // Find active wallpaper image URL
  let activeWallpaperUrl: string | null = null;
  if (wallpaperId === 'custom' && customWallpaperUrl) {
    activeWallpaperUrl = customWallpaperUrl;
  } else if (wallpaperId && wallpaperId !== 'none') {
    const found = BUILTIN_WALLPAPERS.find((w) => w.id === wallpaperId);
    if (found) activeWallpaperUrl = found.url;
  }

  // Theme gradients & color palettes
  const getThemeGradients = () => {
    switch (theme) {
      case 'aurora':
        return {
          bg: 'bg-[#041312]',
          orb1: 'bg-emerald-500/25',
          orb2: 'bg-teal-500/20',
          orb3: 'bg-cyan-600/15',
        };
      case 'twilight':
        return {
          bg: 'bg-[#0d091a]',
          orb1: 'bg-purple-600/25',
          orb2: 'bg-rose-500/20',
          orb3: 'bg-amber-500/15',
        };
      case 'monochrome':
        return {
          bg: 'bg-[#0a0a0c]',
          orb1: 'bg-slate-400/10',
          orb2: 'bg-zinc-500/10',
          orb3: 'bg-slate-700/15',
        };
      case 'obsidian':
      default:
        return {
          bg: 'bg-[#080a14]',
          orb1: 'bg-indigo-600/25',
          orb2: 'bg-blue-500/20',
          orb3: 'bg-violet-600/15',
        };
    }
  };

  const currentTheme = getThemeGradients();

  // Mode subtle tint
  const modeTint =
    mode === 'shortBreak'
      ? 'from-teal-950/30 via-transparent to-transparent'
      : mode === 'stopwatch'
      ? 'from-purple-950/25 via-transparent to-transparent'
      : 'from-transparent via-transparent to-transparent';

  return (
    <div className={`fixed inset-0 pointer-events-none overflow-hidden transition-colors duration-1000 ${currentTheme.bg} -z-10`}>
      {/* 4K Wallpaper / Custom Background Layer */}
      {activeWallpaperUrl && (
        <div
          className="absolute inset-0 bg-cover bg-center transition-all duration-1000 scale-[1.03]"
          style={{
            backgroundImage: `url(${activeWallpaperUrl})`,
            filter: `blur(${wallpaperBlur}px) brightness(${wallpaperBrightness / 100})`,
          }}
        />
      )}

      {/* Dynamic Ambient Orbs (blended smoothly with wallpaper) */}
      <div
        className={`absolute -top-32 -left-32 w-[600px] h-[600px] rounded-full blur-[140px] ${currentTheme.orb1} animate-float-slow transition-all duration-1000 ${
          activeWallpaperUrl ? 'opacity-35 mix-blend-screen' : 'opacity-75'
        } ${isRunning ? 'scale-105' : 'scale-95'}`}
      />
      <div
        className={`absolute top-1/3 -right-36 w-[550px] h-[550px] rounded-full blur-[130px] ${currentTheme.orb2} animate-float-reverse transition-all duration-1000 ${
          activeWallpaperUrl ? 'opacity-30 mix-blend-screen' : 'opacity-65'
        } ${isRunning ? 'scale-110' : 'scale-90'}`}
      />
      <div
        className={`absolute -bottom-36 left-1/3 w-[650px] h-[650px] rounded-full blur-[150px] ${currentTheme.orb3} animate-float-slow transition-all duration-1000 ${
          activeWallpaperUrl ? 'opacity-25 mix-blend-screen' : 'opacity-60'
        }`}
      />

      {/* Mode subtle glow overlay */}
      <div className={`absolute inset-0 bg-gradient-to-b ${modeTint} transition-opacity duration-700`} />

      {/* Deep Frosted Glass Vignette Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_30%,rgba(0,0,0,0.65)_100%)]" />
      <div className="absolute inset-0 bg-black/25" />
    </div>
  );
};
