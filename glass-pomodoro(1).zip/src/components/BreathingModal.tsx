import React, { useState, useEffect } from 'react';
import { Wind, Play, Pause, RotateCcw, X, Info } from 'lucide-react';
import { BreathingTechnique } from '../types';
import { soundEngine } from '../utils/audio';

interface BreathingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Step {
  label: 'Inhale' | 'Hold' | 'Exhale' | 'Rest';
  duration: number; // in seconds
  color: string;
}

const TECHNIQUES: Record<
  BreathingTechnique,
  { name: string; subtitle: string; description: string; steps: Step[] }
> = {
  box: {
    name: 'Box Breathing',
    subtitle: '4s Inhale · 4s Hold · 4s Exhale · 4s Rest',
    description: 'Navy SEAL-tested protocol to calm the nervous system and sharpen acute focus.',
    steps: [
      { label: 'Inhale', duration: 4, color: '#ffffff' },
      { label: 'Hold', duration: 4, color: '#e2e8f0' },
      { label: 'Exhale', duration: 4, color: '#cbd5e1' },
      { label: 'Rest', duration: 4, color: '#94a3b8' },
    ],
  },
  478: {
    name: '4-7-8 Relax',
    subtitle: '4s Inhale · 7s Hold · 8s Exhale',
    description: 'Natural tranquilizer for anxiety and overthinking. Perfect during longer breaks.',
    steps: [
      { label: 'Inhale', duration: 4, color: '#ffffff' },
      { label: 'Hold', duration: 7, color: '#e2e8f0' },
      { label: 'Exhale', duration: 8, color: '#cbd5e1' },
    ],
  },
  calm: {
    name: 'Deep Calm',
    subtitle: '5s Inhale · 5s Exhale',
    description: 'Coherence resonance breathing to sync heart rate variability and induce deep peace.',
    steps: [
      { label: 'Inhale', duration: 5, color: '#ffffff' },
      { label: 'Exhale', duration: 5, color: '#cbd5e1' },
    ],
  },
};

export const BreathingModal: React.FC<BreathingModalProps> = ({ isOpen, onClose }) => {
  const [technique, setTechnique] = useState<BreathingTechnique>('box');
  const [isActive, setIsActive] = useState<boolean>(true);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [secondsLeftInStep, setSecondsLeftInStep] = useState<number>(4);
  const [completedCycles, setCompletedCycles] = useState<number>(0);

  const activeTech = TECHNIQUES[technique];
  const currentStep = activeTech.steps[currentStepIndex] || activeTech.steps[0];

  // Reset when technique changes
  useEffect(() => {
    setCurrentStepIndex(0);
    setSecondsLeftInStep(activeTech.steps[0].duration);
    setCompletedCycles(0);
  }, [technique]);

  // Timer loop for breathing phases
  useEffect(() => {
    if (!isOpen || !isActive) return;

    const interval = setInterval(() => {
      setSecondsLeftInStep((prev) => {
        if (prev <= 1) {
          // Advance to next step
          setCurrentStepIndex((prevIndex) => {
            const nextIndex = (prevIndex + 1) % activeTech.steps.length;
            if (nextIndex === 0) {
              setCompletedCycles((c) => c + 1);
            }
            return nextIndex;
          });
          // Audio feedback on phase switch
          soundEngine.playClick();
          return activeTech.steps[(currentStepIndex + 1) % activeTech.steps.length].duration;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, isActive, activeTech, currentStepIndex]);

  if (!isOpen) return null;

  // Scale computation for breathing circle
  const isExpanding = currentStep.label === 'Inhale';
  const isHolding = currentStep.label === 'Hold' || currentStep.label === 'Rest';
  const isContracting = currentStep.label === 'Exhale';

  let scaleClass = 'scale-100';
  if (isExpanding) {
    scaleClass = 'scale-125';
  } else if (isHolding) {
    scaleClass = currentStep.label === 'Hold' ? 'scale-125' : 'scale-90';
  } else if (isContracting) {
    scaleClass = 'scale-90';
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-xl transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-md rounded-3xl glass-panel border border-white/[0.2] p-5 sm:p-6 text-white shadow-2xl backdrop-blur-2xl z-10 flex flex-col items-center">
        {/* Header */}
        <div className="w-full flex items-center justify-between pb-3 border-b border-white/[0.1]">
          <div className="flex items-center gap-2">
            <Wind className="w-4 h-4 text-white" />
            <span className="text-sm font-semibold tracking-wide">Guided Breathwork</span>
          </div>
          <button
            onClick={onClose}
            aria-label="Close breathing exercise"
            className="p-1 rounded-full text-white/50 hover:text-white hover:bg-white/[0.08] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Technique Switcher Tabs */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-white/[0.05] border border-white/[0.1] my-4 w-full justify-between">
          {(Object.keys(TECHNIQUES) as BreathingTechnique[]).map((key) => {
            const isSel = technique === key;
            return (
              <button
                key={key}
                onClick={() => {
                  setTechnique(key);
                  soundEngine.playClick();
                }}
                className={`flex-1 py-1.5 text-xs font-medium rounded-xl transition-all ${
                  isSel
                    ? 'bg-white text-slate-950 shadow-md font-semibold'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                {TECHNIQUES[key].name}
              </button>
            );
          })}
        </div>

        {/* Big Breathing Visual Orb - Pure White Glassy Ring */}
        <div className="relative w-64 h-64 my-4 flex items-center justify-center">
          {/* Animated Glow Rings */}
          <div
            className={`absolute inset-0 rounded-full border border-white/20 bg-white/[0.06] blur-xl transition-all duration-[3000ms] ease-in-out ${scaleClass}`}
            style={{ opacity: isActive ? 0.7 : 0.2 }}
          />

          <div
            className={`absolute w-52 h-52 rounded-full border-2 border-white/40 transition-all duration-[3000ms] ease-in-out ${scaleClass} flex items-center justify-center shadow-[0_0_50px_rgba(255,255,255,0.2),inset_0_1px_2px_rgba(255,255,255,0.5)]`}
            style={{
              background: 'radial-gradient(circle, rgba(255,255,255,0.14) 0%, transparent 70%)',
            }}
          >
            {/* Center Content */}
            <div className="flex flex-col items-center text-center select-none">
              <span className="text-xs uppercase tracking-[0.25em] font-semibold mb-1 text-white/90">
                {currentStep.label}
              </span>
              <span className="text-4xl font-extralight tracking-tight font-mono-numbers text-white">
                {secondsLeftInStep}s
              </span>
              <span className="text-[11px] text-white/50 mt-1 font-mono-numbers">
                Cycle {completedCycles + 1}
              </span>
            </div>
          </div>
        </div>

        {/* Phase subtitle */}
        <p className="text-xs text-white/70 text-center max-w-xs mb-4">
          {activeTech.description}
        </p>

        {/* Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setCurrentStepIndex(0);
              setSecondsLeftInStep(activeTech.steps[0].duration);
              setCompletedCycles(0);
              soundEngine.playClick();
            }}
            title="Reset exercise"
            className="p-2.5 rounded-full bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.1] text-white/70 hover:text-white transition-all hover:scale-105 active:scale-95"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              setIsActive(!isActive);
              soundEngine.playClick();
            }}
            className={`px-5 py-2 rounded-full text-xs font-semibold flex items-center gap-2 transition-all shadow-md hover:scale-105 active:scale-95 ${
              isActive
                ? 'bg-white/[0.1] hover:bg-white/[0.18] border border-white/[0.2] text-white'
                : 'bg-white text-slate-950 hover:bg-white/90'
            }`}
          >
            {isActive ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-current" />
                <span>Pause</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Resume</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
