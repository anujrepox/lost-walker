import React, { useState, useEffect } from 'react';
import { Check, Edit2, X, ListTodo, Clock } from 'lucide-react';
import { soundEngine } from '../utils/audio';
import { formatDuration } from '../utils/formatTime';

interface FocusTaskInputProps {
  activeTaskText?: string;
  activeTaskTimeSpent?: number;
  onOpenTodoList: () => void;
  onCompleteActiveTask?: () => void;
  onClearActiveTask?: () => void;
  onSetCustomTask?: (text: string) => void;
}

export const FocusTaskInput: React.FC<FocusTaskInputProps> = ({
  activeTaskText,
  activeTaskTimeSpent,
  onOpenTodoList,
  onCompleteActiveTask,
  onClearActiveTask,
  onSetCustomTask,
}) => {
  const [task, setTask] = useState<string>(() => {
    return activeTaskText || localStorage.getItem('glass_pomo_task') || '';
  });
  const [isEditing, setIsEditing] = useState(false);
  const [tempValue, setTempValue] = useState(task);

  useEffect(() => {
    if (activeTaskText !== undefined) {
      setTask(activeTaskText);
      setTempValue(activeTaskText);
    }
  }, [activeTaskText]);

  const handleSave = () => {
    const trimmed = tempValue.trim();
    setTask(trimmed);
    localStorage.setItem('glass_pomo_task', trimmed);
    if (onSetCustomTask) onSetCustomTask(trimmed);
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSave();
    } else if (e.key === 'Escape') {
      setTempValue(task);
      setIsEditing(false);
    }
  };

  const handleComplete = () => {
    soundEngine.playChime();
    setTask('');
    setTempValue('');
    localStorage.removeItem('glass_pomo_task');
    if (onCompleteActiveTask) onCompleteActiveTask();
  };

  const handleClear = () => {
    setTask('');
    setTempValue('');
    localStorage.removeItem('glass_pomo_task');
    if (onClearActiveTask) onClearActiveTask();
  };

  if (isEditing) {
    return (
      <div className="w-full max-w-sm flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.07] border border-white/[0.2] backdrop-blur-xl shadow-lg">
        <input
          type="text"
          value={tempValue}
          onChange={(e) => setTempValue(e.target.value)}
          onKeyDown={handleKeyDown}
          autoFocus
          placeholder="Focus intention..."
          className="w-full bg-transparent text-xs text-white placeholder-white/40 outline-none"
        />
        <button
          onClick={handleSave}
          aria-label="Save intention"
          className="p-1 rounded-full text-white/70 hover:text-white transition-colors"
        >
          <Check className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => {
            setTempValue(task);
            setIsEditing(false);
          }}
          aria-label="Cancel editing"
          className="p-1 rounded-full text-white/40 hover:text-white transition-colors"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  if (task) {
    return (
      <div className="w-full max-w-sm flex items-center justify-between px-3.5 py-1.5 rounded-full bg-white/[0.08] border border-white/30 backdrop-blur-2xl shadow-[0_4px_20px_rgba(255,255,255,0.06),inset_0_1px_1px_rgba(255,255,255,0.25)] transition-all duration-200 group">
        <div className="flex items-center gap-2 overflow-hidden flex-1 min-w-0 mr-1.5">
          <button
            onClick={handleComplete}
            aria-label="Complete task"
            title="Mark as done"
            className="w-3.5 h-3.5 rounded-full border border-white/50 flex items-center justify-center hover:bg-white/30 hover:border-white transition-all shrink-0"
          >
            <Check className="w-2 h-2 text-white opacity-0 hover:opacity-100 transition-opacity" />
          </button>
          <span className="text-xs text-white/95 truncate tracking-wide font-normal">
            {task}
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {/* Active Task Time Spent (simple white text) */}
          {activeTaskTimeSpent !== undefined && (
            <span
              title="Time spent focusing on this task"
              className="text-[11px] font-mono-numbers text-white/80 font-normal tracking-tight"
            >
              {formatDuration(activeTaskTimeSpent)}
            </span>
          )}

          <button
            onClick={() => {
              setTempValue(task);
              setIsEditing(true);
            }}
            aria-label="Edit task"
            className="p-1 text-white/40 hover:text-white transition-colors opacity-0 group-hover:opacity-100"
          >
            <Edit2 className="w-3 h-3" />
          </button>
          <button
            onClick={handleClear}
            aria-label="Clear task"
            className="p-1 text-white/40 hover:text-white transition-colors opacity-0 group-hover:opacity-100"
          >
            <X className="w-3 h-3" />
          </button>
          <button
            onClick={onOpenTodoList}
            aria-label="Open task list"
            title="Open tasks"
            className="p-1 text-white/40 hover:text-white transition-colors ml-0.5"
          >
            <ListTodo className="w-3.5 h-3.5 text-white/70 hover:text-white" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={() => setIsEditing(true)}
        className="text-[11px] sm:text-xs text-white/50 hover:text-white/90 py-1 px-3 rounded-full border border-transparent hover:border-white/10 hover:bg-white/[0.04] transition-all duration-200 cursor-pointer"
      >
        + Set focus intention
      </button>
      <span className="text-white/20 text-xs">·</span>
      <button
        onClick={onOpenTodoList}
        className="flex items-center gap-1.5 text-[11px] sm:text-xs text-white/60 hover:text-white py-1 px-2.5 rounded-full border border-transparent hover:border-white/10 hover:bg-white/[0.06] transition-all duration-200 cursor-pointer"
      >
        <ListTodo className="w-3.5 h-3.5 text-white/80" />
        <span>To-Do List</span>
      </button>
    </div>
  );
};
