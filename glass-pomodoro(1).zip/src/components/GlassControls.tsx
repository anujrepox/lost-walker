import React from 'react';
import { Play, Pause, RotateCcw, SkipForward } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface GlassControlsProps {
  isRunning: boolean;
  isStopwatch?: boolean;
  onTogglePlay: () => void;
  onReset: () => void;
  onSkip?: () => void;
  sessionCount?: number;
}

export const GlassControls: React.FC<GlassControlsProps> = ({
  isRunning,
  isStopwatch = false,
  onTogglePlay,
  onReset,
  onSkip,
}) => {
  const handlePlayToggle = () => {
    soundEngine.playClick();
    onTogglePlay();
  };

  const handleReset = () => {
    soundEngine.playClick();
    onReset();
  };

  const handleSkip = () => {
    if (!onSkip) return;
    soundEngine.playClick();
    onSkip();
  };

  return (
    <div className="flex flex-col items-center gap-3 sm:gap-4 shrink-0">
      {/* Control Buttons Cluster */}
      <div className="flex items-center gap-4 sm:gap-5">
        {/* Reset Button */}
        <button
          onClick={handleReset}
          aria-label="Reset timer"
          title="Reset (R)"
          className="p-3 sm:p-3.5 rounded-full glass-button-secondary text-white/70 hover:text-white transition-all duration-200 hover:scale-105 active:scale-95 outline-none focus-visible:ring-2 focus-visible:ring-white/40"
        >
          <RotateCcw className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
        </button>

        {/* Primary Play/Pause Button */}
        <button
          onClick={handlePlayToggle}
          aria-label={isRunning ? 'Pause' : 'Start'}
          title={isRunning ? 'Pause (Space)' : 'Start (Space)'}
          className="relative group p-4 sm:p-5 rounded-full glass-button-primary text-white transition-all duration-200 hover:scale-105 active:scale-95 outline-none focus-visible:ring-2 focus-visible:ring-white/50"
        >
          <div className="absolute inset-0 rounded-full bg-white/20 blur-md opacity-0 group-hover:opacity-40 transition-opacity duration-300" />
          {isRunning ? (
            <Pause className="w-6 h-6 sm:w-7 sm:h-7 fill-current relative z-10" />
          ) : (
            <Play className="w-6 h-6 sm:w-7 sm:h-7 fill-current translate-x-0.5 relative z-10" />
          )}
        </button>

        {/* Skip Button (Only in Pomodoro & Break modes, hidden in stopwatch) */}
        {!isStopwatch ? (
          <button
            onClick={handleSkip}
            aria-label="Skip to next session"
            title="Skip (S)"
            className="p-3 sm:p-3.5 rounded-full glass-button-secondary text-white/70 hover:text-white transition-all duration-200 hover:scale-105 active:scale-95 outline-none focus-visible:ring-2 focus-visible:ring-white/40"
          >
            <SkipForward className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </button>
        ) : (
          <div className="w-10 sm:w-11" /> /* Spacer to keep play centered */
        )}
      </div>
    </div>
  );
};
