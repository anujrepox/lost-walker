import React from 'react';
import {
  Settings,
  Maximize2,
  Minimize2,
  Keyboard,
  ListTodo,
  Wind,
  Radio,
  EyeOff,
} from 'lucide-react';
import { SoundBar } from './SoundBar';
import { AmbientSound } from '../types';

interface GlassHeaderProps {
  currentSound: AmbientSound;
  onSelectSound: (sound: AmbientSound) => void;
  volume: number;
  onVolumeChange: (vol: number) => void;
  onOpenSettings: () => void;
  onOpenShortcuts: () => void;
  onOpenTodos: () => void;
  onOpenBreathing: () => void;
  onToggleMusic: () => void;
  isMusicOpen: boolean;
  onToggleZen: () => void;
  todoCount: number;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  completedToday: number;
}

export const GlassHeader: React.FC<GlassHeaderProps> = ({
  currentSound,
  onSelectSound,
  volume,
  onVolumeChange,
  onOpenSettings,
  onOpenShortcuts,
  onOpenTodos,
  onOpenBreathing,
  onToggleMusic,
  isMusicOpen,
  onToggleZen,
  todoCount,
  isFullscreen,
  onToggleFullscreen,
}) => {
  return (
    <header className="w-full max-w-6xl mx-auto px-3 sm:px-6 py-2 sm:py-3 flex items-center justify-between z-30 shrink-0">
      {/* Zone 1: Brand Wordmark */}
      <div className="flex items-center gap-2">
        <span className="text-xs sm:text-sm font-semibold tracking-[0.2em] text-white/90 uppercase font-mono-numbers">
          Lost Walker
        </span>

        {/* Breathing Quick Trigger - Pure White Glossy styling */}
        <button
          onClick={onOpenBreathing}
          aria-label="Open guided breathing"
          title="Box Breathing (B)"
          className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/[0.08] hover:bg-white/[0.18] border border-white/[0.2] text-white text-[11px] font-medium transition-all shadow-[inset_0_1px_1px_rgba(255,255,255,0.3)] hover:scale-105 active:scale-95"
        >
          <Wind className="w-3.5 h-3.5 text-white stroke-[2.2]" />
          <span>Breathe</span>
        </button>
      </div>

      {/* Zone 2: Clean Date Display */}
      <div className="hidden sm:flex items-center gap-2 text-xs text-white/70 font-mono-numbers tracking-wide">
        <span>
          {new Date().toLocaleDateString(undefined, {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
          })}
        </span>
      </div>

      {/* Zone 3: Interactive Glass Controls */}
      <div className="flex items-center gap-1 sm:gap-2">
        {/* Zen Mode Button (Z) - White Glossy styling */}
        <button
          onClick={onToggleZen}
          aria-label="Zen mode"
          title="Zen Mode: Hide distractions (Z)"
          className="p-2 rounded-full bg-white/[0.05] hover:bg-white/[0.12] border border-white/[0.1] text-white/80 hover:text-white transition-all duration-200 outline-none hover:scale-105 active:scale-95 shadow-[inset_0_1px_1px_rgba(255,255,255,0.2)]"
        >
          <EyeOff className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white stroke-[2]" />
        </button>

        {/* Lo-Fi Music Radio Widget Toggle (L) */}
        <button
          onClick={onToggleMusic}
          aria-label="Toggle Lo-Fi radio widget"
          title="Lo-Fi Radio & Beats (L)"
          className={`p-2 rounded-full border transition-all duration-200 outline-none hover:scale-105 active:scale-95 ${
            isMusicOpen
              ? 'bg-white/[0.22] border-white/[0.4] text-white shadow-[0_0_15px_rgba(255,255,255,0.3)]'
              : 'bg-white/[0.05] hover:bg-white/[0.12] border-white/[0.1] text-white/80 hover:text-white'
          }`}
        >
          <Radio className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
        </button>

        {/* Mobile Breathe button */}
        <button
          onClick={onOpenBreathing}
          aria-label="Open breathing"
          title="Box Breathing (B)"
          className="md:hidden p-2 rounded-full bg-white/[0.08] hover:bg-white/[0.16] border border-white/[0.15] text-white transition-all duration-200 outline-none"
        >
          <Wind className="w-3.5 h-3.5 text-white" />
        </button>

        {/* Todo List Button - White Glossy styling */}
        <button
          onClick={onOpenTodos}
          aria-label="Open to-do list"
          title="To-Do List (T)"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/[0.08] hover:bg-white/[0.18] border border-white/[0.2] text-xs font-medium text-white transition-all duration-200 outline-none shadow-[inset_0_1px_1px_rgba(255,255,255,0.3)] hover:scale-105 active:scale-95"
        >
          <ListTodo className="w-3.5 h-3.5 text-white stroke-[2.2]" />
          <span className="hidden sm:inline">Tasks</span>
          {todoCount > 0 && (
            <span className="w-4 h-4 rounded-full bg-white/[0.25] text-white text-[10px] font-mono-numbers flex items-center justify-center border border-white/40 shadow-sm font-semibold">
              {todoCount}
            </span>
          )}
        </button>

        {/* Ambient Sound Selector */}
        <SoundBar
          currentSound={currentSound}
          onSelectSound={onSelectSound}
          volume={volume}
          onVolumeChange={onVolumeChange}
        />

        {/* Shortcuts */}
        <button
          onClick={onOpenShortcuts}
          aria-label="Keyboard shortcuts"
          title="Shortcuts (?)"
          className="hidden sm:flex p-2 rounded-full bg-white/[0.05] hover:bg-white/[0.12] border border-white/[0.1] text-white/70 hover:text-white transition-all duration-200 outline-none hover:scale-105 active:scale-95"
        >
          <Keyboard className="w-4 h-4" />
        </button>

        {/* Fullscreen */}
        <button
          onClick={onToggleFullscreen}
          aria-label={isFullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}
          title={isFullscreen ? 'Exit Fullscreen (F)' : 'Fullscreen (F)'}
          className="p-2 rounded-full bg-white/[0.05] hover:bg-white/[0.12] border border-white/[0.1] text-white/70 hover:text-white transition-all duration-200 outline-none hover:scale-105 active:scale-95"
        >
          {isFullscreen ? (
            <Minimize2 className="w-4 h-4" />
          ) : (
            <Maximize2 className="w-4 h-4" />
          )}
        </button>

        {/* Settings */}
        <button
          onClick={onOpenSettings}
          aria-label="Settings"
          title="Settings"
          className="p-2 rounded-full bg-white/[0.05] hover:bg-white/[0.12] border border-white/[0.1] text-white/70 hover:text-white transition-all duration-200 outline-none hover:scale-105 active:scale-95"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
