import React from 'react';
import { motion } from 'motion/react';
import { Timer, Coffee, Clock } from 'lucide-react';
import { TimerMode } from '../types';

interface ModeSelectorProps {
  currentMode: TimerMode;
  onSelectMode: (mode: TimerMode) => void;
  isRunning: boolean;
}

export const ModeSelector: React.FC<ModeSelectorProps> = ({
  currentMode,
  onSelectMode,
}) => {
  const modes: { id: TimerMode; label: string; icon: React.ReactNode }[] = [
    { id: 'focus', label: 'Pomodoro', icon: <Timer className="w-3.5 h-3.5" /> },
    { id: 'shortBreak', label: 'Break', icon: <Coffee className="w-3.5 h-3.5" /> },
    { id: 'stopwatch', label: 'Stopwatch', icon: <Clock className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="relative inline-flex items-center p-1 sm:p-1.5 rounded-full bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-[0_8px_30px_rgba(0,0,0,0.25)]">
      {modes.map((mode) => {
        const isActive = currentMode === mode.id;
        return (
          <button
            key={mode.id}
            onClick={() => onSelectMode(mode.id)}
            className={`relative z-10 flex items-center gap-1.5 px-3.5 sm:px-4 py-1.5 sm:py-2 text-xs sm:text-sm font-medium transition-colors duration-200 rounded-full outline-none focus-visible:ring-2 focus-visible:ring-white/40 whitespace-nowrap ${
              isActive
                ? 'text-white'
                : 'text-white/60 hover:text-white/90'
            }`}
          >
            {isActive && (
              <motion.div
                layoutId="activeModePill"
                className="absolute inset-0 rounded-full bg-white/[0.14] border border-white/[0.22] shadow-[inset_0_1px_1px_rgba(255,255,255,0.3)]"
                transition={{ type: 'spring', stiffness: 450, damping: 35 }}
              />
            )}
            <span className="relative z-10 text-white/80">{mode.icon}</span>
            <span className="relative z-10 tracking-wide">{mode.label}</span>
          </button>
        );
      })}
    </div>
  );
};
