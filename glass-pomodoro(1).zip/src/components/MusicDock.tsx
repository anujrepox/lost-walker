import React, { useState, useRef, useEffect } from 'react';
import {
  Radio,
  Music2,
  X,
  ChevronUp,
  ChevronDown,
  Upload,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  Trash2,
  FolderOpen,
  ListMusic,
  Repeat,
} from 'lucide-react';
import { MusicStation } from '../types';

interface MusicDockProps {
  isOpen: boolean;
  onToggle: () => void;
}

interface LocalTrack {
  id: string;
  name: string;
  size: string;
  file: File;
  url: string;
}

const STREAM_STATIONS: MusicStation[] = [
  {
    id: 'lofi-girl',
    name: 'Lofi Girl - Beats to Relax/Study',
    description: 'Chilled beats stream directly from YouTube',
    type: 'youtube',
    embedUrl: 'https://www.youtube.com/embed/jfKfPfyJRdk?autoplay=1&mute=0',
  },
  {
    id: 'synthwave-radio',
    name: 'Synthwave / Chillwave Radio',
    description: 'Retro futuristic focus rhythms',
    type: 'youtube',
    embedUrl: 'https://www.youtube.com/embed/4xDzrJKXOOY?autoplay=1&mute=0',
  },
  {
    id: 'coffee-shop',
    name: 'Warm Coffee Shop Ambiance',
    description: 'Acoustic guitar & soft jazz cafe atmosphere',
    type: 'youtube',
    embedUrl: 'https://www.youtube.com/embed/5qap5aO4i9A?autoplay=1&mute=0',
  },
  {
    id: 'piano-peace',
    name: 'Deep Focus Classical Piano',
    description: 'Peaceful piano solos for intense coding and writing',
    type: 'youtube',
    embedUrl: 'https://www.youtube.com/embed/WPni755-Krg?autoplay=1&mute=0',
  },
];

export const MusicDock: React.FC<MusicDockProps> = ({ isOpen, onToggle }) => {
  // Mode: 'streams' | 'local'
  const [sourceMode, setSourceMode] = useState<'streams' | 'local'>('streams');

  // Stream state
  const [activeStationId, setActiveStationId] = useState<string>(() => {
    return localStorage.getItem('glass_pomo_station_id') || STREAM_STATIONS[0].id;
  });
  const [isStreamPlaying, setIsStreamPlaying] = useState<boolean>(false);
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);

  // Local audio files state
  const [localTracks, setLocalTracks] = useState<LocalTrack[]>([]);
  const [currentTrackIndex, setCurrentTrackIndex] = useState<number>(0);
  const [isLocalPlaying, setIsLocalPlaying] = useState<boolean>(false);
  const [localVolume, setLocalVolume] = useState<number>(0.7);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [isLooping, setIsLooping] = useState<boolean>(true);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Clean up object URLs on unmount
  useEffect(() => {
    return () => {
      localTracks.forEach((t) => URL.revokeObjectURL(t.url));
    };
  }, [localTracks]);

  // Audio element event listeners
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.volume = localVolume;
    audio.loop = isLooping && localTracks.length === 1;

    const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
    const handleLoadedMetadata = () => setDuration(audio.duration || 0);
    const handleEnded = () => {
      if (localTracks.length > 1) {
        handleNextTrack();
      } else if (!isLooping) {
        setIsLocalPlaying(false);
      }
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [localTracks, currentTrackIndex, isLooping, localVolume]);

  const activeStation = STREAM_STATIONS.find((s) => s.id === activeStationId) || STREAM_STATIONS[0];
  const currentTrack = localTracks[currentTrackIndex] || null;

  // Stream handlers
  const handleSelectStation = (id: string) => {
    // Pause any local audio
    if (audioRef.current && isLocalPlaying) {
      audioRef.current.pause();
      setIsLocalPlaying(false);
    }
    setActiveStationId(id);
    setIsStreamPlaying(true);
    localStorage.setItem('glass_pomo_station_id', id);
  };

  const handleStopStream = () => {
    setIsStreamPlaying(false);
  };

  // Local audio file uploads
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    // Stop live stream if active
    if (isStreamPlaying) setIsStreamPlaying(false);

    const newTracks: LocalTrack[] = Array.from(files).map((file) => ({
      id: 'track_' + Math.random().toString(36).substring(2, 9),
      name: file.name.replace(/\.[^/.]+$/, ''), // Clean file name without extension
      size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
      file,
      url: URL.createObjectURL(file),
    }));

    setLocalTracks((prev) => [...prev, ...newTracks]);
    setSourceMode('local');

    // Auto play if first time adding
    if (localTracks.length === 0 && newTracks.length > 0) {
      setCurrentTrackIndex(0);
      setTimeout(() => {
        if (audioRef.current) {
          audioRef.current.src = newTracks[0].url;
          audioRef.current.play().then(() => setIsLocalPlaying(true)).catch(() => {});
        }
      }, 100);
    }

    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handlePlayLocalTrack = (index: number) => {
    if (isStreamPlaying) setIsStreamPlaying(false);
    setCurrentTrackIndex(index);
    const track = localTracks[index];
    if (audioRef.current && track) {
      audioRef.current.src = track.url;
      audioRef.current.play().then(() => setIsLocalPlaying(true)).catch(() => {});
    }
  };

  const handleTogglePlayPause = () => {
    if (!audioRef.current || !currentTrack) return;
    if (isLocalPlaying) {
      audioRef.current.pause();
      setIsLocalPlaying(false);
    } else {
      if (isStreamPlaying) setIsStreamPlaying(false);
      audioRef.current.play().then(() => setIsLocalPlaying(true)).catch(() => {});
    }
  };

  const handleNextTrack = () => {
    if (localTracks.length === 0) return;
    const nextIdx = (currentTrackIndex + 1) % localTracks.length;
    handlePlayLocalTrack(nextIdx);
  };

  const handlePrevTrack = () => {
    if (localTracks.length === 0) return;
    const prevIdx = (currentTrackIndex - 1 + localTracks.length) % localTracks.length;
    handlePlayLocalTrack(prevIdx);
  };

  const handleRemoveTrack = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const trackToRemove = localTracks.find((t) => t.id === id);
    if (trackToRemove) URL.revokeObjectURL(trackToRemove.url);

    const filtered = localTracks.filter((t) => t.id !== id);
    setLocalTracks(filtered);

    if (currentTrack?.id === id) {
      if (audioRef.current) {
        audioRef.current.pause();
        setIsLocalPlaying(false);
      }
      if (filtered.length > 0) {
        setCurrentTrackIndex(0);
      }
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setCurrentTime(val);
    if (audioRef.current) {
      audioRef.current.currentTime = val;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setLocalVolume(val);
    if (audioRef.current) {
      audioRef.current.volume = val;
    }
  };

  const formatSecs = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  if (!isOpen) return null;

  const isAnyActive = (sourceMode === 'streams' && isStreamPlaying) || (sourceMode === 'local' && isLocalPlaying);

  return (
    <div className="fixed bottom-4 left-4 z-40 max-w-sm w-[calc(100vw-2rem)] sm:w-88 select-none">
      {/* Hidden Native Audio Element for Local Files */}
      <audio ref={audioRef} preload="auto" />

      <div className="rounded-2xl glass-panel border border-white/[0.2] shadow-2xl backdrop-blur-2xl overflow-hidden text-white transition-all duration-300">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-3.5 py-2.5 bg-white/[0.04] border-b border-white/[0.08]">
          <div className="flex items-center gap-2">
            <Radio className="w-3.5 h-3.5 text-white" />
            <span className="text-xs font-semibold tracking-wide">Lo-Fi Radio & Audio</span>
            {isAnyActive && (
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
              </span>
            )}
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsCollapsed(!isCollapsed)}
              aria-label={isCollapsed ? 'Expand player' : 'Collapse player'}
              className="p-1 rounded-md text-white/50 hover:text-white hover:bg-white/[0.08] transition-colors"
            >
              {isCollapsed ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={onToggle}
              aria-label="Close radio"
              className="p-1 rounded-md text-white/50 hover:text-white hover:bg-white/[0.08] transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Body */}
        {!isCollapsed && (
          <div className="p-3 space-y-2.5">
            {/* Source Switcher Tabs: Online Streams vs Local Audio */}
            <div className="flex rounded-xl bg-white/[0.05] p-1 border border-white/[0.08]">
              <button
                onClick={() => setSourceMode('streams')}
                className={`flex-1 py-1 px-2 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${
                  sourceMode === 'streams'
                    ? 'bg-white/[0.18] text-white shadow-sm border border-white/[0.2]'
                    : 'text-white/60 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                <Radio className="w-3 h-3" />
                <span>Lo-Fi Streams</span>
              </button>
              <button
                onClick={() => setSourceMode('local')}
                className={`flex-1 py-1 px-2 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${
                  sourceMode === 'local'
                    ? 'bg-white/[0.18] text-white shadow-sm border border-white/[0.2]'
                    : 'text-white/60 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                <FolderOpen className="w-3 h-3" />
                <span>My Downloaded Audio</span>
                {localTracks.length > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-white/[0.2] text-[10px] font-mono-numbers">
                    {localTracks.length}
                  </span>
                )}
              </button>
            </div>

            {/* TAB 1: ONLINE LO-FI STREAMS */}
            {sourceMode === 'streams' && (
              <>
                {isStreamPlaying ? (
                  <div className="relative aspect-video w-full rounded-xl overflow-hidden bg-black/60 border border-white/[0.1] shadow-inner">
                    <iframe
                      src={activeStation.embedUrl}
                      title={activeStation.name}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      className="w-full h-full border-0"
                    />
                  </div>
                ) : (
                  <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/[0.08] text-center flex flex-col items-center">
                    <Music2 className="w-4 h-4 text-white/40 mb-1" />
                    <p className="text-[11px] text-white/70">Pick a stream below to start background beats</p>
                  </div>
                )}

                {/* Station selector list */}
                <div className="space-y-1 max-h-36 overflow-y-auto pr-0.5">
                  {STREAM_STATIONS.map((station) => {
                    const isSelected = station.id === activeStationId;
                    return (
                      <button
                        key={station.id}
                        onClick={() => handleSelectStation(station.id)}
                        className={`w-full flex items-center justify-between p-2 rounded-xl text-left transition-all ${
                          isSelected && isStreamPlaying
                            ? 'bg-white/[0.18] border border-white/[0.3] text-white shadow-[inset_0_1px_1px_rgba(255,255,255,0.2)]'
                            : 'hover:bg-white/[0.06] border border-transparent text-white/80'
                        }`}
                      >
                        <div className="min-w-0 pr-2">
                          <div className="text-[11px] font-medium truncate flex items-center gap-1.5">
                            <span>{station.name}</span>
                          </div>
                          <div className="text-[9px] text-white/50 truncate">{station.description}</div>
                        </div>
                        {isSelected && isStreamPlaying ? (
                          <span className="text-[10px] text-white font-mono-numbers shrink-0 font-semibold">Playing</span>
                        ) : (
                          <span className="text-[10px] text-white/40 hover:text-white shrink-0">Play</span>
                        )}
                      </button>
                    );
                  })}
                </div>

                {isStreamPlaying && (
                  <button
                    onClick={handleStopStream}
                    className="w-full py-1 text-[11px] text-white/50 hover:text-white transition-colors"
                  >
                    Stop stream
                  </button>
                )}
              </>
            )}

            {/* TAB 2: LOCAL DOWNLOADED AUDIO (FROM USER'S SYSTEM) */}
            {sourceMode === 'local' && (
              <div className="space-y-2.5">
                {/* File Upload Trigger */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="audio/*"
                  multiple
                  onChange={handleFileUpload}
                  className="hidden"
                />

                {localTracks.length === 0 ? (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="p-5 rounded-xl border border-dashed border-white/20 hover:border-white/40 bg-white/[0.02] hover:bg-white/[0.05] text-center cursor-pointer transition-all flex flex-col items-center group"
                  >
                    <div className="p-2.5 rounded-full bg-white/[0.06] group-hover:bg-white/[0.12] mb-2 transition-all">
                      <Upload className="w-5 h-5 text-white/80" />
                    </div>
                    <p className="text-xs font-medium text-white mb-0.5">Play downloaded music from your system</p>
                    <p className="text-[10px] text-white/50">MP3, WAV, FLAC, AAC, M4A or OGG</p>
                    <span className="mt-2.5 px-3 py-1 rounded-full bg-white/[0.1] hover:bg-white/[0.2] border border-white/[0.15] text-[11px] font-medium text-white">
                      Select Audio Files
                    </span>
                  </div>
                ) : (
                  <>
                    {/* Active Track Player Card */}
                    <div className="p-3 rounded-xl bg-white/[0.05] border border-white/[0.12] space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="min-w-0 pr-2">
                          <p className="text-xs font-semibold text-white truncate">
                            {currentTrack ? currentTrack.name : 'No track selected'}
                          </p>
                          <p className="text-[10px] text-white/50">
                            Track {currentTrackIndex + 1} of {localTracks.length}
                          </p>
                        </div>
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          title="Add more local tracks"
                          className="p-1.5 rounded-lg bg-white/[0.08] hover:bg-white/[0.15] text-white text-xs flex items-center gap-1 transition-all"
                        >
                          <Upload className="w-3 h-3" />
                          <span className="text-[10px]">Add</span>
                        </button>
                      </div>

                      {/* Scrubber Progress Slider */}
                      <div className="space-y-1">
                        <input
                          type="range"
                          min="0"
                          max={duration || 100}
                          value={currentTime}
                          onChange={handleSeek}
                          className="w-full h-1 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white"
                        />
                        <div className="flex justify-between text-[9px] font-mono-numbers text-white/50">
                          <span>{formatSecs(currentTime)}</span>
                          <span>{formatSecs(duration)}</span>
                        </div>
                      </div>

                      {/* Playback Controls */}
                      <div className="flex items-center justify-between pt-1">
                        <button
                          onClick={() => setIsLooping(!isLooping)}
                          title={isLooping ? 'Repeat On' : 'Repeat Off'}
                          className={`p-1.5 rounded-md transition-colors ${
                            isLooping ? 'text-white bg-white/[0.15]' : 'text-white/40 hover:text-white'
                          }`}
                        >
                          <Repeat className="w-3.5 h-3.5" />
                        </button>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={handlePrevTrack}
                            disabled={localTracks.length <= 1}
                            className="p-1.5 rounded-full hover:bg-white/[0.1] text-white/70 hover:text-white disabled:opacity-30 transition-all"
                          >
                            <SkipBack className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={handleTogglePlayPause}
                            className="p-2 rounded-full bg-white text-black hover:bg-white/90 shadow-md transition-all active:scale-95"
                          >
                            {isLocalPlaying ? (
                              <Pause className="w-4 h-4 fill-current" />
                            ) : (
                              <Play className="w-4 h-4 fill-current translate-x-0.5" />
                            )}
                          </button>

                          <button
                            onClick={handleNextTrack}
                            disabled={localTracks.length <= 1}
                            className="p-1.5 rounded-full hover:bg-white/[0.1] text-white/70 hover:text-white disabled:opacity-30 transition-all"
                          >
                            <SkipForward className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Volume slider */}
                        <div className="flex items-center gap-1.5 w-20">
                          <Volume2 className="w-3 h-3 text-white/50 shrink-0" />
                          <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.05"
                            value={localVolume}
                            onChange={handleVolumeChange}
                            className="w-full h-1 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Playlist Track List */}
                    <div className="space-y-1 max-h-36 overflow-y-auto pr-0.5">
                      {localTracks.map((track, idx) => {
                        const isSelected = idx === currentTrackIndex;
                        return (
                          <div
                            key={track.id}
                            onClick={() => handlePlayLocalTrack(idx)}
                            className={`w-full flex items-center justify-between p-2 rounded-xl text-left cursor-pointer transition-all group ${
                              isSelected
                                ? 'bg-white/[0.18] border border-white/[0.25] text-white'
                                : 'hover:bg-white/[0.06] border border-transparent text-white/80'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0 pr-2">
                              <span className="text-[10px] font-mono-numbers text-white/40 w-4 text-center shrink-0">
                                {isSelected && isLocalPlaying ? '▶' : idx + 1}
                              </span>
                              <div className="min-w-0">
                                <p className="text-[11px] font-medium truncate">{track.name}</p>
                                <p className="text-[9px] text-white/40">{track.size}</p>
                              </div>
                            </div>

                            <button
                              onClick={(e) => handleRemoveTrack(e, track.id)}
                              title="Remove from playlist"
                              className="p-1 rounded text-white/30 hover:text-white/90 hover:bg-white/[0.1] opacity-0 group-hover:opacity-100 transition-all"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
