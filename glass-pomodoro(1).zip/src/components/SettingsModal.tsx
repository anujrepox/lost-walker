import React, { useState, useRef } from 'react';
import { X, Bell, Moon, Sliders, Check, Image as ImageIcon, Upload, Link2, Eye, Sun, Sparkles } from 'lucide-react';
import { TimerSettings, GlassTheme } from '../types';
import { BUILTIN_WALLPAPERS } from '../utils/wallpapers';
import { soundEngine } from '../utils/audio';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: TimerSettings;
  onUpdateSettings: (newSettings: Partial<TimerSettings>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  const [customInputUrl, setCustomInputUrl] = useState(settings.customWallpaperUrl || '');
  const [urlInputError, setUrlInputError] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const categories = [
    { id: 'all', label: 'All' },
    { id: 'nature', label: 'Nature' },
    { id: 'cosmic', label: 'Cosmic' },
    { id: 'cozy', label: 'Cozy / Lo-Fi' },
    { id: 'cyber', label: 'Cyberpunk' },
    { id: 'minimal', label: 'Minimal' },
    { id: 'anime', label: 'Aesthetic' },
  ];

  const filteredWallpapers = selectedCategory === 'all'
    ? BUILTIN_WALLPAPERS
    : BUILTIN_WALLPAPERS.filter((wp) => wp.category === selectedCategory);

  const themes: { id: GlassTheme; label: string; preview: string }[] = [
    { id: 'obsidian', label: 'Obsidian', preview: 'bg-indigo-900 border-indigo-400' },
    { id: 'aurora', label: 'Aurora', preview: 'bg-emerald-900 border-emerald-400' },
    { id: 'twilight', label: 'Twilight', preview: 'bg-purple-900 border-rose-400' },
    { id: 'monochrome', label: 'Monochrome', preview: 'bg-zinc-800 border-zinc-400' },
  ];

  // Handle local image file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 8 * 1024 * 1024) {
        alert('Please choose an image under 8MB');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        try {
          localStorage.setItem('glass_pomo_custom_bg', base64);
        } catch {
          // ignore
        }
        onUpdateSettings({
          wallpaperId: 'custom',
          customWallpaperUrl: base64,
        });
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle custom URL input
  const handleApplyUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInputUrl.trim()) return;
    try {
      new URL(customInputUrl.trim());
      setUrlInputError(false);
      onUpdateSettings({
        wallpaperId: 'custom',
        customWallpaperUrl: customInputUrl.trim(),
      });
    } catch {
      setUrlInputError(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-lg rounded-3xl glass-panel border border-white/[0.2] p-5 sm:p-6 text-white shadow-2xl backdrop-blur-2xl z-10 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-white/[0.1]">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-white/70" />
            <span className="text-sm font-semibold tracking-wide">Settings</span>
          </div>
          <button
            onClick={onClose}
            aria-label="Close settings"
            className="p-1 rounded-full text-white/50 hover:text-white hover:bg-white/[0.08] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* SECTION 1: 4K WALLPAPERS & CUSTOM BACKGROUND */}
        <div className="py-4 border-b border-white/[0.08] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-cyan-300" />
              <span className="text-xs uppercase tracking-wider font-semibold text-white/90">
                4K Wallpapers & Background
              </span>
            </div>
            {settings.wallpaperId !== 'none' && (
              <button
                onClick={() => onUpdateSettings({ wallpaperId: 'none' })}
                className="text-[11px] text-white/50 hover:text-white/90 underline decoration-white/30"
              >
                Reset to Pure Glass
              </button>
            )}
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            {categories.map((cat) => {
              const isActive = selectedCategory === cat.id;
              const count = cat.id === 'all'
                ? BUILTIN_WALLPAPERS.length
                : BUILTIN_WALLPAPERS.filter((w) => w.category === cat.id).length;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-2.5 py-1 rounded-full text-[11px] whitespace-nowrap transition-all flex items-center gap-1 shrink-0 ${
                    isActive
                      ? 'bg-white text-slate-950 font-semibold shadow-sm'
                      : 'bg-white/[0.06] hover:bg-white/[0.12] text-white/70 hover:text-white border border-white/[0.08]'
                  }`}
                >
                  <span>{cat.label}</span>
                  <span className={`text-[9px] opacity-60 font-mono-numbers`}>{count}</span>
                </button>
              );
            })}
          </div>

          {/* Built-in 4K Wallpapers Grid (Scrollable for rich collection) */}
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 pt-1 max-h-64 overflow-y-auto pr-1">
            {selectedCategory === 'all' && (
              <button
                onClick={() => onUpdateSettings({ wallpaperId: 'none' })}
                className={`relative h-20 rounded-xl overflow-hidden border transition-all text-center flex flex-col items-center justify-center p-1.5 ${
                  settings.wallpaperId === 'none'
                    ? 'border-cyan-400 ring-2 ring-cyan-400/40 bg-white/[0.12]'
                    : 'border-white/[0.12] hover:border-white/30 bg-white/[0.04]'
                }`}
              >
                <Sparkles className="w-5 h-5 text-white/60 mb-1" />
                <span className="text-[10px] text-white/80 font-medium">Pure Glass</span>
                {settings.wallpaperId === 'none' && (
                  <div className="absolute top-1 right-1 w-3.5 h-3.5 rounded-full flex items-center justify-center glass-check-glossy">
                    <Check className="w-2.5 h-2.5 text-slate-950 stroke-[3]" />
                  </div>
                )}
              </button>
            )}

            {filteredWallpapers.map((wp) => {
              const isSelected = settings.wallpaperId === wp.id;
              return (
                <button
                  key={wp.id}
                  onClick={() => onUpdateSettings({ wallpaperId: wp.id })}
                  className={`group relative h-20 rounded-xl overflow-hidden border transition-all text-left ${
                    isSelected
                      ? 'border-cyan-400 ring-2 ring-cyan-400/40'
                      : 'border-white/[0.1] hover:border-white/30'
                  }`}
                >
                  <img
                    src={wp.thumbnail}
                    alt={wp.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end p-1.5">
                    <span className="text-[10px] text-white/90 font-medium truncate leading-tight">
                      {wp.name}
                    </span>
                  </div>
                  {isSelected && (
                    <div className="absolute top-1 right-1 w-3.5 h-3.5 rounded-full flex items-center justify-center glass-check-glossy">
                      <Check className="w-2.5 h-2.5 text-slate-950 stroke-[3]" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Custom Background Actions */}
          <div className="pt-2 space-y-2">
            <span className="text-[11px] text-white/60 font-medium block">
              Or Use Your Own Custom Image:
            </span>
            <div className="flex flex-col sm:flex-row items-center gap-2">
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className={`w-full sm:w-auto shrink-0 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium border transition-all ${
                  settings.wallpaperId === 'custom' && !settings.customWallpaperUrl?.startsWith('http')
                    ? 'bg-cyan-500/20 border-cyan-400/60 text-white'
                    : 'bg-white/[0.06] hover:bg-white/[0.12] border-white/[0.12] text-white/80'
                }`}
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Image</span>
              </button>

              <form onSubmit={handleApplyUrl} className="w-full flex items-center gap-1.5">
                <div className="relative flex-1">
                  <input
                    type="url"
                    value={customInputUrl}
                    onChange={(e) => {
                      setCustomInputUrl(e.target.value);
                      setUrlInputError(false);
                    }}
                    placeholder="Paste image link (https://...)"
                    className={`w-full bg-white/[0.06] border rounded-xl px-3 py-1.5 text-xs text-white placeholder-white/40 outline-none pr-7 ${
                      urlInputError ? 'border-rose-400' : 'border-white/[0.12] focus:border-white/30'
                    }`}
                  />
                  <Link2 className="w-3.5 h-3.5 text-white/30 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
                <button
                  type="submit"
                  disabled={!customInputUrl.trim()}
                  className="px-3 py-1.5 text-xs font-medium rounded-xl bg-white text-slate-950 hover:bg-white/90 disabled:opacity-40 disabled:pointer-events-none transition-all shadow-sm"
                >
                  Apply
                </button>
              </form>
            </div>
          </div>

          {/* Wallpaper Blur & Brightness Sliders */}
          {settings.wallpaperId !== 'none' && (
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/[0.08] space-y-3 mt-2">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-[11px] text-white/70 w-24 shrink-0">
                  <Eye className="w-3.5 h-3.5 text-white/40" />
                  <span>Blur effect</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="20"
                  step="1"
                  value={settings.wallpaperBlur ?? 4}
                  onChange={(e) =>
                    onUpdateSettings({ wallpaperBlur: parseInt(e.target.value) || 0 })
                  }
                  className="w-full"
                />
                <span className="text-[10px] font-mono-numbers text-white/50 w-8 text-right">
                  {settings.wallpaperBlur ?? 4}px
                </span>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-[11px] text-white/70 w-24 shrink-0">
                  <Sun className="w-3.5 h-3.5 text-white/40" />
                  <span>Dim / Glow</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="100"
                  step="5"
                  value={settings.wallpaperBrightness ?? 50}
                  onChange={(e) =>
                    onUpdateSettings({ wallpaperBrightness: parseInt(e.target.value) || 50 })
                  }
                  className="w-full"
                />
                <span className="text-[10px] font-mono-numbers text-white/50 w-8 text-right">
                  {settings.wallpaperBrightness ?? 50}%
                </span>
              </div>
            </div>
          )}
        </div>

        {/* SECTION 2: TIMER DURATIONS (Long break removed) */}
        <div className="py-4 space-y-4">
          <span className="text-xs uppercase tracking-wider font-semibold text-white/40">
            Timer Durations (Minutes)
          </span>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
              <label className="text-[11px] text-white/60 block mb-1.5 font-medium">Focus Pomodoro</label>
              <input
                type="number"
                min="1"
                max="120"
                value={settings.focusDuration}
                onChange={(e) =>
                  onUpdateSettings({ focusDuration: Math.max(1, parseInt(e.target.value) || 25) })
                }
                className="w-full bg-white/[0.08] border border-white/[0.12] rounded-xl px-2.5 py-1.5 text-center font-mono-numbers text-sm font-semibold text-white outline-none focus:border-white/40"
              />
            </div>

            <div className="p-3 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
              <label className="text-[11px] text-white/60 block mb-1.5 font-medium">Break</label>
              <input
                type="number"
                min="1"
                max="60"
                value={settings.shortBreakDuration}
                onChange={(e) =>
                  onUpdateSettings({ shortBreakDuration: Math.max(1, parseInt(e.target.value) || 5) })
                }
                className="w-full bg-white/[0.08] border border-white/[0.12] rounded-xl px-2.5 py-1.5 text-center font-mono-numbers text-sm font-semibold text-white outline-none focus:border-white/40"
              />
            </div>
          </div>
        </div>

        {/* SECTION 3: AUTOMATION */}
        <div className="py-3 border-t border-white/[0.08] space-y-3">
          <span className="text-xs uppercase tracking-wider font-semibold text-white/40">
            Automation
          </span>

          <label className="flex items-center justify-between cursor-pointer">
            <span className="text-xs text-white/80">Auto-start breaks</span>
            <input
              type="checkbox"
              checked={settings.autoStartBreaks}
              onChange={(e) => onUpdateSettings({ autoStartBreaks: e.target.checked })}
              className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
            />
          </label>

          <label className="flex items-center justify-between cursor-pointer">
            <span className="text-xs text-white/80">Auto-start focus</span>
            <input
              type="checkbox"
              checked={settings.autoStartPomodoros}
              onChange={(e) => onUpdateSettings({ autoStartPomodoros: e.target.checked })}
              className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
            />
          </label>
        </div>

        {/* SECTION 4: GLASS ATMOSPHERES */}
        <div className="py-3 border-t border-white/[0.08] space-y-2.5">
          <div className="flex items-center gap-1.5 text-xs uppercase tracking-wider font-semibold text-white/40">
            <Moon className="w-3.5 h-3.5" />
            <span>Glass Atmosphere</span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {themes.map((t) => {
              const isSelected = settings.theme === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => onUpdateSettings({ theme: t.id })}
                  className={`flex items-center gap-2.5 p-2 rounded-xl border text-xs font-medium transition-all ${
                    isSelected
                      ? 'bg-white/[0.14] border-white/40 text-white'
                      : 'bg-white/[0.03] border-white/[0.08] text-white/60 hover:text-white'
                  }`}
                >
                  <span className={`w-3.5 h-3.5 rounded-full border ${t.preview}`} />
                  <span className="truncate">{t.label}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 ml-auto text-cyan-300" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* SECTION 5: AUDIO PREVIEW */}
        <div className="py-3 border-t border-white/[0.08] flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-white/80">
            <Bell className="w-3.5 h-3.5 text-white/60" />
            <span>Harmonic Bowl Chime</span>
          </div>
          <button
            onClick={() => soundEngine.playChime()}
            className="px-3 py-1 text-xs rounded-full bg-white/[0.08] hover:bg-white/[0.16] border border-white/[0.15] text-white transition-colors"
          >
            Preview
          </button>
        </div>
      </div>
    </div>
  );
};
