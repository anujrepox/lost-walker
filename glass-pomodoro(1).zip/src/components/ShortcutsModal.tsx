import React from 'react';
import { X, Command } from 'lucide-react';

interface ShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const shortcuts = [
    { key: 'Space', desc: 'Start / Pause timer' },
    { key: 'Z', desc: 'Zen Minimalist mode (hide all UI)' },
    { key: 'B', desc: 'Open Guided Breathwork' },
    { key: 'L', desc: 'Toggle Lo-Fi radio dock' },
    { key: 'R', desc: 'Reset current session' },
    { key: 'S', desc: 'Skip to next mode' },
    { key: 'T', desc: 'Open / close to-do tasks' },
    { key: 'F', desc: 'Toggle fullscreen' },
    { key: 'M', desc: 'Toggle ambient sound' },
    { key: '?', desc: 'Keyboard shortcuts guide' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-md"
        onClick={onClose}
      />
      <div className="relative w-full max-w-sm rounded-3xl glass-panel border border-white/[0.2] p-5 text-white shadow-2xl backdrop-blur-2xl z-10 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-white/[0.1] mb-3">
          <div className="flex items-center gap-2">
            <Command className="w-4 h-4 text-white/70" />
            <span className="text-sm font-semibold tracking-wide">Hotkeys</span>
          </div>
          <button
            onClick={onClose}
            aria-label="Close shortcuts"
            className="p-1 rounded-full text-white/50 hover:text-white hover:bg-white/[0.08] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-1.5">
          {shortcuts.map((sc) => (
            <div key={sc.key} className="flex items-center justify-between py-1.5 text-xs">
              <span className="text-white/70">{sc.desc}</span>
              <kbd className="px-2 py-1 rounded-md bg-white/[0.1] border border-white/[0.15] font-mono-numbers text-[11px] text-white">
                {sc.key}
              </kbd>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
