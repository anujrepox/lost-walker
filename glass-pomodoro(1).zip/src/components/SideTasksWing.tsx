import React, { useState } from 'react';
import { Check, CheckCircle2, Circle, Target, Plus, Trash2, Clock } from 'lucide-react';
import { TodoItem } from '../types';
import { soundEngine } from '../utils/audio';
import { formatDuration } from '../utils/formatTime';

interface SideTasksWingProps {
  side: 'left' | 'right';
  title: string;
  todos: TodoItem[];
  activeTodoId: string | null;
  onSelectActiveTodo: (id: string | null) => void;
  onToggleTodo: (id: string) => void;
  onDeleteTodo: (id: string) => void;
  onAddTodo?: (text: string, pomos: number) => void;
  onOpenFullList?: () => void;
}

export const SideTasksWing: React.FC<SideTasksWingProps> = ({
  side,
  title,
  todos,
  activeTodoId,
  onSelectActiveTodo,
  onToggleTodo,
  onDeleteTodo,
  onAddTodo,
  onOpenFullList,
}) => {
  const [isQuickAdding, setIsQuickAdding] = useState(false);
  const [quickText, setQuickText] = useState('');

  const handleQuickAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickText.trim() || !onAddTodo) return;
    soundEngine.playClick();
    onAddTodo(quickText.trim(), 1);
    setQuickText('');
    setIsQuickAdding(false);
  };

  return (
    <div
      className="w-64 xl:w-72 flex flex-col max-h-[460px] p-3.5 rounded-3xl glass-panel border border-white/[0.12] shadow-[0_12px_40px_rgba(0,0,0,0.3)] backdrop-blur-2xl transition-all duration-300 text-left"
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-2.5 mb-2 border-b border-white/[0.08] shrink-0">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold tracking-wider text-white/90 uppercase">
            {title}
          </span>
          <span className="text-[10px] font-mono-numbers px-1.5 py-0.5 rounded-full bg-white/[0.08] text-white/60 border border-white/[0.08]">
            {todos.length}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {onOpenFullList && (
            <button
              onClick={onOpenFullList}
              className="text-[10px] text-white/40 hover:text-white/90 transition-colors"
            >
              All tasks →
            </button>
          )}
        </div>
      </div>

      {/* List items */}
      <div className="flex-1 overflow-y-auto space-y-2 min-h-0 pr-1 select-none">
        {todos.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center py-8 text-white/35">
            <Circle className="w-5 h-5 stroke-[1.2] mb-1.5 text-white/20" />
            <span className="text-[11px] leading-tight">
              {side === 'left' ? 'No active tasks' : 'No completed tasks yet'}
            </span>
          </div>
        ) : (
          todos.map((todo) => {
            const isActive = activeTodoId === todo.id;
            const timeSpent = todo.timeSpentSeconds || 0;

            return (
              <div
                key={todo.id}
                className={`group relative flex items-center justify-between p-2 sm:p-2.5 rounded-2xl border transition-all duration-200 ${
                  isActive
                    ? 'bg-white/[0.12] border-white/40 shadow-[0_4px_20px_rgba(255,255,255,0.08),inset_0_1px_1px_rgba(255,255,255,0.3)]'
                    : todo.completed
                    ? 'bg-white/[0.02] border-white/[0.06] opacity-75'
                    : 'bg-white/[0.04] border-white/[0.1] hover:bg-white/[0.08] hover:border-white/25'
                }`}
              >
                {/* Left: Complete toggle & title */}
                <div className="flex items-center gap-2 overflow-hidden flex-1 min-w-0 mr-1.5">
                  <button
                    onClick={() => {
                      soundEngine.playClick();
                      onToggleTodo(todo.id);
                    }}
                    aria-label={todo.completed ? 'Mark incomplete' : 'Mark done'}
                    className="shrink-0 text-white/50 hover:text-white transition-colors"
                  >
                    {todo.completed ? (
                      <div className="w-4 h-4 rounded-full flex items-center justify-center glass-check-glossy">
                        <Check className="w-2.5 h-2.5 stroke-[3] text-slate-950" />
                      </div>
                    ) : (
                      <Circle className="w-4 h-4 text-white/40 hover:text-white transition-colors" />
                    )}
                  </button>

                  <span
                    className={`text-xs truncate tracking-wide ${
                      todo.completed
                        ? 'line-through text-white/40'
                        : isActive
                        ? 'text-white font-medium'
                        : 'text-white/85'
                    }`}
                  >
                    {todo.text}
                  </span>
                </div>

                {/* Right: Time Spent (simple white text) + Actions */}
                <div className="flex items-center gap-2 shrink-0">
                  {/* Time Spent placed right side of task */}
                  {(todo.completed || timeSpent > 0 || isActive) && (
                    <span
                      title={
                        todo.completed
                          ? `Finished in ${formatDuration(timeSpent)}`
                          : `Time focused: ${formatDuration(timeSpent)}`
                      }
                      className="text-[11px] font-mono-numbers text-white/80 font-normal tracking-tight"
                    >
                      {formatDuration(timeSpent)}
                    </span>
                  )}

                  {!todo.completed && (
                    <button
                      onClick={() => onSelectActiveTodo(isActive ? null : todo.id)}
                      title={isActive ? 'Active focus task' : 'Set as timer target'}
                      className={`p-1 rounded-md transition-colors ${
                        isActive
                          ? 'text-white bg-white/[0.18] shadow-sm'
                          : 'text-white/30 hover:text-white hover:bg-white/[0.08]'
                      }`}
                    >
                      <Target className="w-3.5 h-3.5" />
                    </button>
                  )}

                  <button
                    onClick={() => onDeleteTodo(todo.id)}
                    title="Delete task"
                    className="p-1 rounded-md text-white/20 hover:text-rose-400 transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Quick Add at bottom of Active column */}
      {side === 'left' && onAddTodo && (
        <div className="pt-2 border-t border-white/[0.08] shrink-0 mt-1">
          {isQuickAdding ? (
            <form onSubmit={handleQuickAdd} className="flex items-center gap-1.5">
              <input
                type="text"
                value={quickText}
                onChange={(e) => setQuickText(e.target.value)}
                autoFocus
                placeholder="New task..."
                className="w-full bg-white/[0.08] border border-white/[0.15] rounded-xl px-2.5 py-1 text-xs text-white placeholder-white/40 outline-none"
              />
              <button
                type="submit"
                disabled={!quickText.trim()}
                className="px-2.5 py-1 text-xs rounded-xl bg-white text-slate-950 font-medium disabled:opacity-30"
              >
                Add
              </button>
              <button
                type="button"
                onClick={() => setIsQuickAdding(false)}
                className="text-[11px] text-white/50 hover:text-white px-1"
              >
                ✕
              </button>
            </form>
          ) : (
            <button
              onClick={() => setIsQuickAdding(true)}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.09] text-[11px] text-white/70 hover:text-white transition-colors"
            >
              <Plus className="w-3 h-3" />
              <span>Add Quick Task</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
