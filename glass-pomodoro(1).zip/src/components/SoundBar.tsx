import React, { useState } from 'react';
import { Volume2, VolumeX, CloudRain, Waves, Wind, Sparkles, ChevronDown } from 'lucide-react';
import { AmbientSound } from '../types';
import { soundEngine } from '../utils/audio';

interface SoundBarProps {
  currentSound: AmbientSound;
  onSelectSound: (sound: AmbientSound) => void;
  volume: number;
  onVolumeChange: (vol: number) => void;
}

export const SoundBar: React.FC<SoundBarProps> = ({
  currentSound,
  onSelectSound,
  volume,
  onVolumeChange,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const sounds: { id: AmbientSound; label: string; icon: React.ReactNode }[] = [
    { id: 'none', label: 'Mute', icon: <VolumeX className="w-3.5 h-3.5" /> },
    { id: 'rain', label: 'Rain', icon: <CloudRain className="w-3.5 h-3.5" /> },
    { id: 'stream', label: 'Stream', icon: <Waves className="w-3.5 h-3.5" /> },
    { id: 'brown', label: 'Deep Hum', icon: <Wind className="w-3.5 h-3.5" /> },
    { id: 'drone', label: '432Hz Zen', icon: <Sparkles className="w-3.5 h-3.5" /> },
  ];

  const currentLabel = sounds.find((s) => s.id === currentSound)?.label || 'Sound';

  const handleSoundSelect = (sound: AmbientSound) => {
    soundEngine.playClick();
    onSelectSound(sound);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Ambient sound settings"
        className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-medium border transition-all duration-200 outline-none hover:scale-105 active:scale-95 ${
          currentSound !== 'none'
            ? 'bg-white/[0.18] border-white/[0.3] text-white shadow-[0_0_15px_rgba(255,255,255,0.2),inset_0_1px_1px_rgba(255,255,255,0.3)]'
            : 'bg-white/[0.05] border-white/[0.1] text-white/70 hover:text-white hover:bg-white/[0.08]'
        }`}
      >
        {currentSound === 'none' ? (
          <VolumeX className="w-3.5 h-3.5 text-white/70" />
        ) : (
          <Volume2 className="w-3.5 h-3.5 animate-pulse text-white" />
        )}
        <span>{currentLabel}</span>
        <ChevronDown className={`w-3 h-3 text-white/70 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 mt-2 w-48 rounded-2xl glass-panel border border-white/[0.18] p-2 text-white shadow-2xl backdrop-blur-2xl z-50 flex flex-col gap-1">
            <span className="text-[10px] font-semibold text-white/40 uppercase tracking-wider px-2 py-1">
              Ambient Focus
            </span>

            {/* Sound options */}
            <div className="space-y-0.5">
              {sounds.map((sound) => {
                const isSelected = currentSound === sound.id;
                return (
                  <button
                    key={sound.id}
                    onClick={() => handleSoundSelect(sound.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs transition-colors ${
                      isSelected
                        ? 'bg-white/[0.18] text-white font-medium border border-white/[0.2]'
                        : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      {sound.icon}
                      <span>{sound.label}</span>
                    </div>
                    {isSelected && (
                      <div className="w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_6px_rgba(255,255,255,0.8)]" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Volume Slider */}
            <div className="pt-2 border-t border-white/[0.08] flex items-center gap-3">
              <Volume2 className="w-3.5 h-3.5 text-white/50 shrink-0" />
              <input
                type="range"
                min="0"
                max="1"
                step="0.02"
                value={volume}
                onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
                aria-label="Volume slider"
                className="w-full"
              />
              <span className="text-[10px] font-mono-numbers text-white/50 w-6 text-right">
                {Math.round(volume * 100)}%
              </span>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
