import React from 'react';
import { Plus, Minus } from 'lucide-react';
import { TimerMode, GlassTheme } from '../types';

interface TimerRingProps {
  timeLeft: number;
  totalDuration: number;
  isRunning: boolean;
  mode: TimerMode;
  theme: GlassTheme;
  onAdjustTime: (deltaSeconds: number) => void;
}

export const TimerRing: React.FC<TimerRingProps> = ({
  timeLeft,
  totalDuration,
  isRunning,
  mode,
  theme,
  onAdjustTime,
}) => {
  const isStopwatch = mode === 'stopwatch';

  // For countdown: minutes & seconds left
  // For stopwatch: timeLeft is elapsed time (seconds elapsed)
  const hours = Math.floor(timeLeft / 3600);
  const minutes = Math.floor((timeLeft % 3600) / 60);
  const seconds = timeLeft % 60;

  const formattedHours = String(hours).padStart(2, '0');
  const formattedMinutes = String(minutes).padStart(2, '0');
  const formattedSeconds = String(seconds).padStart(2, '0');

  // Ring geometry
  const radius = 135;
  const strokeWidth = 7;
  const circumference = 2 * Math.PI * radius;

  // Progress calculation
  let progress = 0;
  if (isStopwatch) {
    // For stopwatch, one full rotation every 60 seconds
    progress = (timeLeft % 60) / 60;
  } else {
    // For countdown timer
    progress = totalDuration > 0 ? (totalDuration - timeLeft) / totalDuration : 0;
  }

  const strokeDashoffset = circumference - progress * circumference;

  // Gradient colors by mode / theme
  const getGradientColors = () => {
    if (mode === 'shortBreak') return { start: '#2dd4bf', end: '#06b6d4' };
    if (mode === 'stopwatch') return { start: '#38bdf8', end: '#a855f7' };
    
    switch (theme) {
      case 'aurora':
        return { start: '#34d399', end: '#14b8a6' };
      case 'twilight':
        return { start: '#c084fc', end: '#fb7185' };
      case 'monochrome':
        return { start: '#ffffff', end: '#94a3b8' };
      case 'obsidian':
      default:
        return { start: '#818cf8', end: '#38bdf8' };
    }
  };

  const colors = getGradientColors();

  return (
    <div className="relative flex items-center justify-center select-none group my-1 sm:my-2 shrink-0">
      {/* Outer subtle glass halo */}
      <div
        className={`absolute w-[285px] h-[285px] sm:w-[325px] sm:h-[325px] rounded-full bg-white/[0.02] border border-white/[0.08] backdrop-blur-md shadow-[0_20px_50px_rgba(0,0,0,0.3)] transition-all duration-700 ${
          isRunning ? 'scale-[1.02] shadow-[0_0_50px_rgba(255,255,255,0.06)]' : 'scale-100'
        }`}
      />

      {/* SVG Ring */}
      <svg
        className="w-[280px] h-[280px] sm:w-[320px] sm:h-[320px] -rotate-90 transform relative z-10"
        viewBox="0 0 320 320"
      >
        <defs>
          <linearGradient id="timerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={colors.start} />
            <stop offset="100%" stopColor={colors.end} />
          </linearGradient>
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="5" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Track circle */}
        <circle
          cx="160"
          cy="160"
          r={radius}
          fill="none"
          stroke="rgba(255, 255, 255, 0.08)"
          strokeWidth={strokeWidth}
        />

        {/* Progress active circle */}
        <circle
          cx="160"
          cy="160"
          r={radius}
          fill="none"
          stroke="url(#timerGradient)"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          className="transition-[stroke-dashoffset] duration-700 ease-linear"
          filter={isRunning ? 'url(#glow)' : undefined}
        />
      </svg>

      {/* Center content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center z-20 pointer-events-none">
        {/* Subtle breathing glow under time */}
        <div
          className={`absolute w-28 h-16 rounded-full blur-2xl transition-opacity duration-1000 ${
            isRunning ? 'opacity-30 bg-white/20' : 'opacity-0'
          }`}
        />

        {/* Main Display Time */}
        <div className="relative flex items-center justify-center">
          {hours > 0 && (
            <>
              <span className="text-4xl sm:text-6xl font-light tracking-tight font-mono-numbers text-white drop-shadow-[0_4px_16px_rgba(0,0,0,0.5)]">
                {formattedHours}
              </span>
              <span
                className={`text-4xl sm:text-6xl font-light tracking-tight font-mono-numbers text-white/70 px-0.5 transition-opacity duration-500 ${
                  isRunning ? 'animate-pulse' : 'opacity-90'
                }`}
              >
                :
              </span>
            </>
          )}
          <span
            className={`${
              hours > 0 ? 'text-4xl sm:text-6xl' : 'text-5xl sm:text-7xl'
            } font-light tracking-tight font-mono-numbers text-white drop-shadow-[0_4px_16px_rgba(0,0,0,0.5)]`}
          >
            {formattedMinutes}
          </span>
          <span
            className={`${
              hours > 0 ? 'text-4xl sm:text-6xl' : 'text-5xl sm:text-7xl'
            } font-light tracking-tight font-mono-numbers text-white/70 px-0.5 sm:px-1.5 transition-opacity duration-500 ${
              isRunning ? 'animate-pulse' : 'opacity-90'
            }`}
          >
            :
          </span>
          <span
            className={`${
              hours > 0 ? 'text-4xl sm:text-6xl' : 'text-5xl sm:text-7xl'
            } font-light tracking-tight font-mono-numbers text-white drop-shadow-[0_4px_16px_rgba(0,0,0,0.5)]`}
          >
            {formattedSeconds}
          </span>
        </div>

        {/* Quick adjustment controls (+1m / -1m) (Hidden in stopwatch mode) */}
        {!isStopwatch && (
          <div className="flex items-center gap-3 mt-1.5 pointer-events-auto opacity-35 hover:opacity-100 transition-opacity duration-200">
            <button
              onClick={() => onAdjustTime(-60)}
              disabled={timeLeft <= 60}
              aria-label="Decrease time by 1 minute"
              title="-1 minute"
              className="p-1 rounded-full bg-white/[0.06] hover:bg-white/[0.14] border border-white/[0.1] text-white/80 hover:text-white transition-colors duration-150 disabled:opacity-20 disabled:pointer-events-none"
            >
              <Minus className="w-3 h-3" />
            </button>
            <span className="text-[10px] font-mono-numbers text-white/50 tracking-wider uppercase">
              ± 1 min
            </span>
            <button
              onClick={() => onAdjustTime(60)}
              aria-label="Increase time by 1 minute"
              title="+1 minute"
              className="p-1 rounded-full bg-white/[0.06] hover:bg-white/[0.14] border border-white/[0.1] text-white/80 hover:text-white transition-colors duration-150"
            >
              <Plus className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
