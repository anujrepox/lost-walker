import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, Trash2, Check, CheckCircle2, Circle, Target, Clock } from 'lucide-react';
import { TodoItem } from '../types';
import { soundEngine } from '../utils/audio';
import { formatDuration } from '../utils/formatTime';

interface TodoDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  todos: TodoItem[];
  activeTodoId: string | null;
  onSelectActiveTodo: (id: string | null) => void;
  onAddTodo: (text: string, estimatedPomos: number) => void;
  onToggleTodo: (id: string) => void;
  onDeleteTodo: (id: string) => void;
  onClearCompleted: () => void;
}

export const TodoDrawer: React.FC<TodoDrawerProps> = ({
  isOpen,
  onClose,
  todos,
  activeTodoId,
  onSelectActiveTodo,
  onAddTodo,
  onToggleTodo,
  onDeleteTodo,
  onClearCompleted,
}) => {
  const [newText, setNewText] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const completedCount = todos.filter((t) => t.completed).length;
  const totalCount = todos.length;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;
    soundEngine.playClick();
    onAddTodo(newText.trim(), 1);
    setNewText('');
    setIsAdding(false);
  };

  const handleToggle = (id: string) => {
    soundEngine.playClick();
    onToggleTodo(id);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Backdrop blur */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          />

          {/* Glass Slide-over Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 300 }}
            className="relative w-full max-w-sm sm:max-w-md h-full glass-panel border-l border-white/[0.18] shadow-2xl backdrop-blur-2xl z-10 flex flex-col justify-between text-white"
          >
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-white/[0.1] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <span className="text-sm font-semibold tracking-wide">Tasks</span>
                {totalCount > 0 && (
                  <span className="text-[11px] font-mono-numbers px-2 py-0.5 rounded-full bg-white/[0.08] text-white/70 border border-white/[0.1]">
                    {completedCount}/{totalCount}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1">
                {completedCount > 0 && (
                  <button
                    onClick={onClearCompleted}
                    title="Clear completed tasks"
                    className="p-1.5 rounded-full text-white/40 hover:text-white/80 hover:bg-white/[0.06] text-xs transition-colors"
                  >
                    Clear done
                  </button>
                )}
                <button
                  onClick={onClose}
                  aria-label="Close task list"
                  className="p-1.5 rounded-full text-white/50 hover:text-white hover:bg-white/[0.08] transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Todo List Content */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-2.5 min-h-0">
              {todos.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-12 text-white/40">
                  <Circle className="w-8 h-8 stroke-[1.2] mb-3 text-white/20" />
                  <p className="text-xs tracking-wide">No tasks planned yet</p>
                  <p className="text-[11px] text-white/30 mt-1">
                    Add a focus task below to link it with your timer
                  </p>
                </div>
              ) : (
                todos.map((todo) => {
                  const isActive = activeTodoId === todo.id;
                  const timeSpent = todo.timeSpentSeconds || 0;

                  return (
                    <div
                      key={todo.id}
                      className={`group relative flex items-center justify-between p-3 rounded-2xl border transition-all duration-200 ${
                        isActive
                          ? 'bg-white/[0.12] border-white/40 shadow-[0_4px_20px_rgba(255,255,255,0.08),inset_0_1px_1px_rgba(255,255,255,0.3)]'
                          : todo.completed
                          ? 'bg-white/[0.02] border-white/[0.06] opacity-75'
                          : 'bg-white/[0.04] border-white/[0.1] hover:bg-white/[0.08] hover:border-white/25'
                      }`}
                    >
                      {/* Left: Complete toggle & Text */}
                      <div className="flex items-center gap-3 overflow-hidden flex-1 mr-2 min-w-0">
                        <button
                          onClick={() => handleToggle(todo.id)}
                          aria-label={todo.completed ? 'Mark task as incomplete' : 'Mark task as completed'}
                          className="shrink-0 text-white/50 hover:text-white transition-colors"
                        >
                          {todo.completed ? (
                            <div className="w-4 h-4 rounded-full flex items-center justify-center glass-check-glossy">
                              <Check className="w-2.5 h-2.5 stroke-[3] text-slate-950" />
                            </div>
                          ) : (
                            <Circle className="w-4 h-4 text-white/40 hover:text-white transition-colors" />
                          )}
                        </button>

                        <span
                          className={`text-xs sm:text-sm font-normal truncate tracking-wide ${
                            todo.completed
                              ? 'line-through text-white/40'
                              : isActive
                              ? 'text-white font-medium'
                              : 'text-white/90'
                          }`}
                        >
                          {todo.text}
                        </span>
                      </div>

                      {/* Right: Time Spent (simple white text) + Actions */}
                      <div className="flex items-center gap-2 shrink-0">
                        {/* Time Spent placed right side of task */}
                        {(todo.completed || timeSpent > 0 || isActive) && (
                          <span
                            title={
                              todo.completed
                                ? `Completed in ${formatDuration(timeSpent)}`
                                : `Time spent focusing: ${formatDuration(timeSpent)}`
                            }
                            className="text-xs font-mono-numbers text-white/80 font-normal tracking-tight"
                          >
                            {formatDuration(timeSpent)}
                          </span>
                        )}

                        {!todo.completed && (
                          <button
                            onClick={() => onSelectActiveTodo(isActive ? null : todo.id)}
                            title={isActive ? 'Active timer focus' : 'Focus on this task'}
                            className={`p-1.5 rounded-lg text-xs transition-colors ${
                              isActive
                                ? 'text-white bg-white/[0.18] shadow-sm'
                                : 'text-white/40 hover:text-white hover:bg-white/[0.08]'
                            }`}
                          >
                            <Target className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          onClick={() => onDeleteTodo(todo.id)}
                          title="Delete task"
                          className="p-1.5 rounded-lg text-white/30 hover:text-rose-400 hover:bg-rose-500/10 transition-colors opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Bottom: Add Task Form */}
            <div className="p-4 sm:p-5 border-t border-white/[0.1] shrink-0 bg-white/[0.02]">
              {isAdding ? (
                <form onSubmit={handleAdd} className="space-y-3">
                  <input
                    type="text"
                    value={newText}
                    onChange={(e) => setNewText(e.target.value)}
                    autoFocus
                    placeholder="What will you focus on?"
                    className="w-full bg-white/[0.08] border border-white/[0.18] rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white placeholder-white/40 outline-none focus:border-white/40"
                  />
                  <div className="flex items-center justify-end gap-1.5">
                    <button
                      type="button"
                      onClick={() => setIsAdding(false)}
                      className="px-3 py-1.5 text-xs text-white/60 hover:text-white transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={!newText.trim()}
                      className="px-3.5 py-1.5 text-xs font-medium rounded-xl bg-white text-slate-950 hover:bg-white/90 disabled:opacity-30 disabled:pointer-events-none transition-all shadow-md"
                    >
                      Add
                    </button>
                  </div>
                </form>
              ) : (
                <button
                  onClick={() => setIsAdding(true)}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.12] text-xs font-medium text-white/80 hover:text-white transition-all shadow-sm outline-none"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Task</span>
                </button>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
