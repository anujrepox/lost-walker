export type TimerMode = 'focus' | 'shortBreak' | 'stopwatch';

export type AmbientSound = 'none' | 'rain' | 'stream' | 'brown' | 'drone';

export type GlassTheme = 'obsidian' | 'aurora' | 'twilight' | 'monochrome';

export interface WallpaperOption {
  id: string;
  name: string;
  thumbnail: string;
  url: string;
  category: 'all' | 'nature' | 'cosmic' | 'minimal' | 'cyber' | 'anime' | 'cozy';
}

export interface TimerSettings {
  focusDuration: number; // in minutes
  shortBreakDuration: number;
  autoStartBreaks: boolean;
  autoStartPomodoros: boolean;
  soundEnabled: boolean;
  volume: number;
  theme: GlassTheme;
  wallpaperId: string; // 'none' or built-in ID or 'custom'
  customWallpaperUrl?: string;
  wallpaperBlur: number; // in px
  wallpaperBrightness: number; // in percent (e.g. 40-100)
}

export interface FocusStats {
  completedSessions: number;
  totalFocusMinutes: number;
  streak: number;
  lastActiveDate: string;
}

export interface TodoItem {
  id: string;
  text: string;
  completed: boolean;
  pomodorosEstimated?: number;
  pomodorosSpent?: number;
  timeSpentSeconds?: number; // Total focus seconds tracked on this task
  createdAt: number;
  completedAt?: number;
}

export type BreathingTechnique = 'box' | '478' | 'calm';

export interface MusicStation {
  id: string;
  name: string;
  description: string;
  type: 'youtube' | 'spotify';
  embedUrl: string;
  thumbnail?: string;
}
