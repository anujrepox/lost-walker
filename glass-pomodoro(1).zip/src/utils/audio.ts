// Web Audio API pure synthesizer for ambient focus sounds and session bells
// Zero external assets required - 100% reliable, offline-ready

class SoundEngine {
  private ctx: AudioContext | null = null;
  private ambientGain: GainNode | null = null;
  private ambientNodes: { stop: () => void } | null = null;
  private currentAmbient: 'none' | 'rain' | 'stream' | 'brown' | 'drone' = 'none';
  private masterVolume: number = 0.5;

  private getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public setVolume(vol: number) {
    this.masterVolume = Math.max(0, Math.min(1, vol));
    if (this.ambientGain && this.ctx) {
      this.ambientGain.gain.setValueAtTime(this.masterVolume * 0.4, this.ctx.currentTime);
    }
  }

  // Play serene crystal singing bowl chime for session completion
  public playChime() {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;
      const baseFreq = 528; // Solfeggio 528Hz resonance

      const harmonics = [
        { freq: baseFreq, gain: 0.35, decay: 4.5 },
        { freq: baseFreq * 1.5, gain: 0.18, decay: 3.8 },
        { freq: baseFreq * 2.02, gain: 0.12, decay: 3.2 },
        { freq: baseFreq * 2.75, gain: 0.06, decay: 2.4 },
        { freq: baseFreq * 3.5, gain: 0.03, decay: 1.8 },
      ];

      harmonics.forEach(({ freq, gain, decay }) => {
        const osc = ctx.createOscillator();
        const gainNode = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);

        gainNode.gain.setValueAtTime(0.0001, now);
        gainNode.gain.exponentialRampToValueAtTime(gain * this.masterVolume, now + 0.04);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, now + decay);

        osc.connect(gainNode);
        gainNode.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + decay + 0.1);
      });
    } catch {
      // Audio context might be restricted before user gesture
    }
  }

  // Soft subtle glass tick on button click
  public playClick() {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(220, now + 0.05);

      gain.gain.setValueAtTime(0.08 * this.masterVolume, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.06);
    } catch {
      // ignore
    }
  }

  // Start continuous ambient noise
  public setAmbient(type: 'none' | 'rain' | 'stream' | 'brown' | 'drone') {
    if (this.currentAmbient === type) return;

    this.stopAmbient();
    this.currentAmbient = type;

    if (type === 'none') return;

    try {
      const ctx = this.getContext();
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.001, ctx.currentTime);
      masterGain.gain.exponentialRampToValueAtTime(this.masterVolume * 0.35, ctx.currentTime + 1.2);
      masterGain.connect(ctx.destination);
      this.ambientGain = masterGain;

      if (type === 'brown') {
        this.startBrownNoise(ctx, masterGain);
      } else if (type === 'rain') {
        this.startRainSound(ctx, masterGain);
      } else if (type === 'stream') {
        this.startStreamSound(ctx, masterGain);
      } else if (type === 'drone') {
        this.startBinauralDrone(ctx, masterGain);
      }
    } catch {
      // Audio autoplay restrictions
    }
  }

  public stopAmbient() {
    if (this.ambientNodes) {
      try {
        this.ambientNodes.stop();
      } catch {
        // ignore
      }
      this.ambientNodes = null;
    }
    this.currentAmbient = 'none';
  }

  private createNoiseBuffer(ctx: AudioContext, seconds: number = 5): AudioBuffer {
    const bufferSize = ctx.sampleRate * seconds;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }
    return buffer;
  }

  private startBrownNoise(ctx: AudioContext, dest: GainNode) {
    const bufferSize = ctx.sampleRate * 4;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let lastOut = 0.0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      data[i] = (lastOut + (0.02 * white)) / 1.02;
      lastOut = data[i];
      data[i] *= 3.5; // Gain compensation
    }

    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = buffer;
    noiseSource.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(380, ctx.currentTime);

    noiseSource.connect(filter);
    filter.connect(dest);
    noiseSource.start();

    this.ambientNodes = {
      stop: () => {
        noiseSource.stop();
        noiseSource.disconnect();
      }
    };
  }

  private startRainSound(ctx: AudioContext, dest: GainNode) {
    const noiseBuffer = this.createNoiseBuffer(ctx, 4);
    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    // Highpass to eliminate low thuds
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.setValueAtTime(600, ctx.currentTime);

    // Lowpass for soft soothing drops
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(2600, ctx.currentTime);

    noiseSource.connect(hp);
    hp.connect(lp);
    lp.connect(dest);
    noiseSource.start();

    this.ambientNodes = {
      stop: () => {
        noiseSource.stop();
        noiseSource.disconnect();
      }
    };
  }

  private startStreamSound(ctx: AudioContext, dest: GainNode) {
    const noiseBuffer = this.createNoiseBuffer(ctx, 4);
    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(800, ctx.currentTime);
    bp.Q.setValueAtTime(1.2, ctx.currentTime);

    // Subtle LFO modulation to simulate rippling water
    const lfo = ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.setValueAtTime(0.35, ctx.currentTime);

    const lfoGain = ctx.createGain();
    lfoGain.gain.setValueAtTime(280, ctx.currentTime);
    lfo.connect(lfoGain);
    lfoGain.connect(bp.frequency);

    noiseSource.connect(bp);
    bp.connect(dest);

    noiseSource.start();
    lfo.start();

    this.ambientNodes = {
      stop: () => {
        noiseSource.stop();
        lfo.stop();
        noiseSource.disconnect();
        lfo.disconnect();
      }
    };
  }

  private startBinauralDrone(ctx: AudioContext, dest: GainNode) {
    // 432Hz base frequency + 436Hz binaural theta wave beat (4Hz)
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const harmonic = ctx.createOscillator();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(432, ctx.currentTime);

    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(436, ctx.currentTime);

    harmonic.type = 'sine';
    harmonic.frequency.setValueAtTime(864, ctx.currentTime);

    const harmGain = ctx.createGain();
    harmGain.gain.setValueAtTime(0.15, ctx.currentTime);
    harmonic.connect(harmGain);

    osc1.connect(dest);
    osc2.connect(dest);
    harmGain.connect(dest);

    osc1.start();
    osc2.start();
    harmonic.start();

    this.ambientNodes = {
      stop: () => {
        osc1.stop();
        osc2.stop();
        harmonic.stop();
        osc1.disconnect();
        osc2.disconnect();
        harmonic.disconnect();
      }
    };
  }
}

export const soundEngine = new SoundEngine();
