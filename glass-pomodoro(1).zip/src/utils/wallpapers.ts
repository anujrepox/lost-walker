import { WallpaperOption } from '../types';

export const BUILTIN_WALLPAPERS: WallpaperOption[] = [
  // NATURE & LANDSCAPES
  {
    id: 'misty-pines',
    name: 'Misty Alpine Pines',
    category: 'nature',
    thumbnail: 'https://images.unsplash.com/photo-1511497584788-87676104235f?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1511497584788-87676104235f?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'nordic-aurora',
    name: 'Nordic Aurora',
    category: 'nature',
    thumbnail: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'foggy-lake',
    name: 'Silent Mountain Lake',
    category: 'nature',
    thumbnail: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'kyoto-bamboo',
    name: 'Kyoto Bamboo Grove',
    category: 'nature',
    thumbnail: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'fuji-sunset',
    name: 'Mount Fuji Dusk',
    category: 'nature',
    thumbnail: 'https://images.unsplash.com/photo-1490806843957-31f4c9a91c65?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1490806843957-31f4c9a91c65?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'emerald-waterfall',
    name: 'Cascading Falls',
    category: 'nature',
    thumbnail: 'https://images.unsplash.com/photo-1432405972618-c60b0225b8f9?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1432405972618-c60b0225b8f9?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'autumn-forest',
    name: 'Golden Autumn Mist',
    category: 'nature',
    thumbnail: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=2560&auto=format&fit=crop&q=85',
  },

  // COSMIC & NIGHT SKY
  {
    id: 'deep-cosmos',
    name: 'Deep Nebula',
    category: 'cosmic',
    thumbnail: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'starry-mountains',
    name: 'Milky Way Peaks',
    category: 'cosmic',
    thumbnail: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'galaxy-core',
    name: 'Cosmic Ocean',
    category: 'cosmic',
    thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'star-trails',
    name: 'Desert Starlight',
    category: 'cosmic',
    thumbnail: 'https://images.unsplash.com/photo-1509773896068-7fd415d91e2e?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1509773896068-7fd415d91e2e?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'solar-eclipse',
    name: 'Total Eclipse Corona',
    category: 'cosmic',
    thumbnail: 'https://images.unsplash.com/photo-1532693322450-2cb5c511067d?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1532693322450-2cb5c511067d?w=2560&auto=format&fit=crop&q=85',
  },

  // CYBERPUNK & CITY NIGHTS
  {
    id: 'tokyo-rain',
    name: 'Cyberpunk Tokyo',
    category: 'cyber',
    thumbnail: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'neon-shinjuku',
    name: 'Neon Shinjuku Alley',
    category: 'cyber',
    thumbnail: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'futuristic-skyline',
    name: 'Futuristic Metropolis',
    category: 'cyber',
    thumbnail: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'cyber-highway',
    name: 'Neon Light Trails',
    category: 'cyber',
    thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1542224566-6e85f2e6772f?w=2560&auto=format&fit=crop&q=85',
  },

  // COZY & LO-FI STUDY
  {
    id: 'rainy-window',
    name: 'Raindrops on Glass',
    category: 'cozy',
    thumbnail: 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'cozy-library',
    name: 'Vintage Library Study',
    category: 'cozy',
    thumbnail: 'https://images.unsplash.com/photo-1507842229452-9d10787e95b0?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1507842229452-9d10787e95b0?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'cafe-evening',
    name: 'Warm Coffeehouse',
    category: 'cozy',
    thumbnail: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'lofi-desk',
    name: 'Lo-Fi Studio Desk',
    category: 'cozy',
    thumbnail: 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'fireplace-cabin',
    name: 'Cabin Fire Glow',
    category: 'cozy',
    thumbnail: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=2560&auto=format&fit=crop&q=85',
  },

  // MINIMAL & ABSTRACT
  {
    id: 'obsidian-dune',
    name: 'Dark Sand Dunes',
    category: 'minimal',
    thumbnail: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'minimal-gradient',
    name: 'Liquid Silk Flow',
    category: 'minimal',
    thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'dark-waves',
    name: 'Deep Midnight Ocean',
    category: 'minimal',
    thumbnail: 'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'geometric-glass',
    name: 'Prismatic Glass Geometry',
    category: 'minimal',
    thumbnail: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'monochrome-architecture',
    name: 'Brutalist Shadows',
    category: 'minimal',
    thumbnail: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=2560&auto=format&fit=crop&q=85',
  },

  // ANIME & DREAMY
  {
    id: 'anime-sunset-train',
    name: 'Pastel Sunset Train',
    category: 'anime',
    thumbnail: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'cherry-blossom-night',
    name: 'Sakura Night Street',
    category: 'anime',
    thumbnail: 'https://images.unsplash.com/photo-1528164344705-475426879c0d?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1528164344705-475426879c0d?w=2560&auto=format&fit=crop&q=85',
  },
  {
    id: 'dreamy-clouds',
    name: 'Cotton Twilight Sky',
    category: 'anime',
    thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=2560&auto=format&fit=crop&q=85',
  },
];
